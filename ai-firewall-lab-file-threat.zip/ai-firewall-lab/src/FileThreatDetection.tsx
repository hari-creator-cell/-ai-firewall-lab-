import { useCallback, useEffect, useRef, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { CompanionError, RequestView, StatusView, createCompanionClient, fileToBase64 } from "./lib/companion";
import { SafeText } from "./lib/SafeText";
import "./fileThreat.css";

type Sync = { state: "idle" | "pending" | "saved" | "failed" | "skipped"; message: string };
const DEFAULT_URL = "http://127.0.0.1:8787";
const TERMINAL = ["rejected", "blocked", "completed", "error", "cancelled"];

function badge(view: RequestView | null, busy: boolean): { label: string; cls: string } {
  if (busy && (!view || view.state === "running" || view.state === "received" || view.state === "ready")) return { label: "PROCESSING", cls: "processing" };
  if (!view) return { label: "IDLE", cls: "idle" };
  if (view.state === "cancelled") return { label: "CANCELLED", cls: "review" };
  if (view.state === "error") return { label: "ERROR", cls: "error" };
  const d = view.policy?.display;
  if (d === "ALLOWED") return { label: "SAFE / ALLOWED", cls: "allowed" };
  if (d === "REVIEW") return { label: "SUSPICIOUS / REVIEW", cls: "review" };
  if (d === "ERROR") return { label: "ERROR", cls: "error" };
  return { label: "BLOCKED", cls: "blocked" };
}

export default function FileThreatDetection({ session }: { session: Session | null }) {
  const [url, setUrl] = useState(() => sessionStorage.getItem("afl_companion_url") || DEFAULT_URL);
  const [token, setToken] = useState(() => sessionStorage.getItem("afl_companion_token") || "");
  const [online, setOnline] = useState<"unknown" | "online" | "offline">("unknown");
  const [status, setStatus] = useState<StatusView | null>(null);
  const [connMsg, setConnMsg] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState("Summarize this document and list its key points.");
  const [view, setView] = useState<RequestView | null>(null);
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState("");
  const [error, setError] = useState("");
  const [sync, setSync] = useState<Sync>({ state: "idle", message: "" });
  const runAbort = useRef<AbortController | null>(null);
  const activeId = useRef<string | null>(null);

  const refreshStatus = useCallback(async () => {
    try {
      const c = createCompanionClient(url, token);
      await c.ping(); setOnline("online");
      if (token) { setStatus(await c.status()); setConnMsg(""); } else setConnMsg("Companion is online. Paste the pairing token printed in its console.");
    } catch (e) {
      if (e instanceof CompanionError && e.status === 401) { setOnline("online"); setStatus(null); setConnMsg("Pairing token rejected."); }
      else { setOnline("offline"); setStatus(null); setConnMsg(e instanceof Error ? e.message : "Unreachable"); }
    }
  }, [url, token]);

  useEffect(() => { void refreshStatus(); const t = setInterval(() => void refreshStatus(), 10_000); return () => clearInterval(t); }, [refreshStatus]);

  function savePairing() {
    sessionStorage.setItem("afl_companion_url", url); sessionStorage.setItem("afl_companion_token", token);
    void refreshStatus();
  }

  async function syncAudit(id: string) {
    if (!session?.access_token) { setSync({ state: "skipped", message: "Not signed in: audit exists only in the local companion file." }); return; }
    setSync({ state: "pending", message: "Syncing audit record to Supabase…" });
    try {
      const exp = await createCompanionClient(url, token).auditExport(id);
      if (!exp.signature) { setSync({ state: "skipped", message: "Companion has no AUDIT_SYNC_SECRET; Supabase sync disabled. Local audit only." }); return; }
      const res = await fetch("/api/file-audit", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` }, body: JSON.stringify({ record: exp.record, signature: exp.signature }) });
      const data = await res.json().catch(() => ({}));
      if (res.ok) setSync({ state: "saved", message: "Saved to Supabase (file_scan_audit)." });
      else setSync({ state: "failed", message: `Supabase sync failed: ${(data as { error?: string }).error || res.status}. Local audit file is unaffected.` });
    } catch (e) {
      setSync({ state: "failed", message: `Supabase sync failed: ${e instanceof Error ? e.message : "unknown error"}` });
    }
  }

  async function analyze() {
    if (!file || busy) return;
    setBusy(true); setError(""); setView(null); setSync({ state: "idle", message: "" });
    const client = createCompanionClient(url, token);
    let poll: ReturnType<typeof setInterval> | null = null;
    try {
      setStage("Reading file in the browser…");
      const b64 = await fileToBase64(file);
      setStage("Validating and scanning (server-side)…");
      let v = await client.submit(file.name, b64);
      activeId.current = v.requestId; setView(v);
      if (v.decision === "allow" && v.state === "ready") {
        setStage("Allowed — waiting for Qwen via Ollama…");
        const ac = new AbortController(); runAbort.current = ac;
        poll = setInterval(() => { const id = activeId.current; if (id) client.get(id).then(setView).catch(() => undefined); }, 700);
        try { v = await client.run(v.requestId, prompt, ac.signal); }
        catch (e) {
          if (e instanceof DOMException && e.name === "AbortError") v = await client.get(v.requestId);
          else throw e;
        }
        setView(v);
      }
      setStage("");
      if (TERMINAL.includes(v.state)) await syncAudit(v.requestId);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unexpected error");
      setStage("");
    } finally {
      if (poll) clearInterval(poll);
      runAbort.current = null; setBusy(false);
    }
  }

  async function emergencyStop() {
    const id = activeId.current;
    if (!id) return;
    runAbort.current?.abort();
    try { setView(await createCompanionClient(url, token).cancel(id)); }
    catch (e) { setError(`Emergency Stop request failed: ${e instanceof Error ? e.message : "unknown"}. The request may still be running.`); }
  }

  const b = badge(view, busy);
  const paired = online === "online" && !!status;
  const ollamaOk = !!status?.ollama.reachable && !!status?.ollama.modelAvailable;
  const maxKb = status ? Math.round(status.limits.maxFileBytes / 1024) : 512;

  return (
    <section className="ftd" aria-labelledby="ftd-title">
      <div className="ftd-head">
        <div><p className="eyebrow">LOCAL ENFORCEMENT · OLLAMA + QWEN3</p><h2 id="ftd-title">File Threat Detection</h2>
          <p className="muted">Files are validated and scanned by a local companion service <b>before</b> anything is sent to the model. The allow/block decision is made server-side; this page only displays it.</p></div>
        <span className={`pill ${b.cls}`}>{b.label}</span>
      </div>

      <div className="ftd-grid">
        <div className="panel">
          <p className="eyebrow">MODEL STATUS</p>
          <ul className="kv">
            <li><span>Companion</span><b className={online === "online" ? "ok" : "bad"}>{online === "online" ? (paired ? "Online · paired" : "Online · not paired") : online === "offline" ? "Offline" : "Checking…"}</b></li>
            <li><span>Ollama</span><b className={status ? (status.ollama.reachable ? "ok" : "bad") : ""}>{status ? (status.ollama.reachable ? "Connected" : "Not reachable") : "—"}</b></li>
            <li><span>Model</span><b><SafeText text={status?.model ?? "qwen3:1.7b"} max={60} /></b></li>
            <li><span>Availability</span><b className={status ? (status.ollama.modelAvailable ? "ok" : "bad") : ""}>{status ? (status.ollama.modelAvailable ? "Installed" : "Not installed") : "—"}</b></li>
            <li><span>Request state</span><b>{view ? view.state : busy ? "starting" : "idle"}</b></li>
          </ul>
          {status?.ollama.error && <p className="notice">{status.ollama.error}</p>}
          {connMsg && !paired && <p className="notice">{connMsg}</p>}
          <details open={!paired}><summary>Companion connection</summary>
            <div className="stack">
              <label>Companion URL<input value={url} onChange={e => setUrl(e.target.value)} /></label>
              <label>Pairing token<input type="password" autoComplete="off" value={token} onChange={e => setToken(e.target.value)} placeholder="printed in the companion console" /></label>
              <button type="button" className="secondary small" onClick={savePairing}>Connect</button>
            </div></details>
        </div>

        <div className="panel">
          <p className="eyebrow">FILE UPLOAD</p>
          <div className="stack">
            <label>Select a file
              <input type="file" onChange={e => { setFile(e.target.files?.[0] ?? null); setView(null); setError(""); setSync({ state: "idle", message: "" }); }} disabled={busy} />
            </label>
            {file && <p className="muted small-text">Selected: <SafeText as="code" text={file.name} max={100} /> · {(file.size / 1024).toFixed(1)} KB</p>}
            <p className="muted small-text">Supported (plain text only): {status ? status.supportedExtensions.join(" ") : ".txt .md .csv .json .log and common source files"} · max {maxKb} KB. PDF/DOCX/binaries are rejected, not scanned.</p>
            <label>Task for Qwen<input value={prompt} maxLength={500} onChange={e => setPrompt(e.target.value)} disabled={busy} /></label>
            <div className="button-row">
              <button type="button" disabled={!file || busy || !paired} onClick={() => void analyze()}>{busy ? "Working…" : "Upload & scan"}</button>
              <button type="button" className="danger" disabled={!busy && !(view && !TERMINAL.includes(view.state))} onClick={() => void emergencyStop()}>■ Emergency Stop</button>
            </div>
            {busy && <div className="progress" role="progressbar" aria-label="Processing"><i /></div>}
            {stage && <p className="muted small-text">{stage}</p>}
            {error && <p className="notice err">{error}</p>}
          </div>
        </div>
      </div>

      <div className="ftd-grid">
        <div className="panel">
          <p className="eyebrow">THREAT ANALYSIS</p>
          {!view ? <p className="muted">No request yet.</p> : <>
            <ul className="kv">
              <li><span>Scan status</span><b>{view.scan ? (view.scan.status === "ok" ? "Completed" : "Failed") : "Not run (rejected at validation)"}</b></li>
              <li><span>Risk level</span><b>{view.policy?.riskLevel ?? "—"}{view.scan ? ` (score ${view.scan.riskScore}/100)` : ""}</b></li>
              <li><span>Policy decision</span><b className={view.decision === "allow" ? "ok" : "bad"}>{view.decision.toUpperCase()}</b></li>
              <li><span>Sent to Qwen</span><b className={view.forwardedToModel ? "warn" : "ok"}>{view.forwardedToModel ? `Yes (${view.forwardedChars} chars)` : "No"}</b></li>
            </ul>
            {view.policy && <p className="muted"><SafeText text={view.policy.reason} max={300} /></p>}
            {view.file?.truncatedForModel && <p className="notice">File is longer than the model limit: the whole file was scanned, only the first part can be sent.</p>}
            {view.scan && view.scan.findings.length > 0 && <ol className="findings">{view.scan.findings.map((f, i) => (
              <li key={i}><div><b><SafeText text={f.category} max={80} /></b> <span className="score">+{f.score}</span></div>
                <p className="muted small-text"><SafeText text={f.explanation} max={300} /></p>
                <SafeText as="pre" className="excerpt" text={f.excerpt} max={160} /></li>))}</ol>}
            {view.scan && <p className="muted small-text">{view.scan.disclaimer}</p>}
          </>}
        </div>

        <div className="panel">
          <p className="eyebrow">AI RESPONSE</p>
          {!view && <p className="muted">Waiting for a request.</p>}
          {view?.state === "blocked" && <div className="blocked-box"><b>BLOCKED — the file was not sent to Qwen.</b><p><SafeText text={view.policy?.reason} max={300} /></p></div>}
          {view?.state === "rejected" && <div className="blocked-box"><b>REJECTED before scanning — nothing was sent to Qwen.</b><p><SafeText text={view.policy?.reason} max={300} /></p></div>}
          {view?.state === "cancelled" && <div className="blocked-box"><b>CANCELLED.</b><p><SafeText text={view.cancelNote} max={400} /></p></div>}
          {view?.state === "error" && <div className="blocked-box err"><b>Model error:</b> <SafeText text={view.error?.message} max={300} /><p className="muted small-text">The document was not processed by Qwen.</p></div>}
          {view?.state === "running" && <p className="muted">Qwen is working…</p>}
          {view?.response && <><SafeText as="pre" className="answer" text={view.response.text} max={8000} />
            <p className="muted small-text">Model: <SafeText text={view.response.model} max={60} />{view.response.totalDurationMs != null ? ` · ${(view.response.totalDurationMs / 1000).toFixed(1)}s` : ""}</p></>}
          {view && view.toolCalls.length > 0 && <ul className="kv">{view.toolCalls.map((t, i) => <li key={i}><span>Tool: <SafeText text={t.name} max={40} /></span><b className={t.executed ? "warn" : "ok"}>{t.executed ? "executed" : "denied"}</b></li>)}</ul>}
        </div>
      </div>

      <div className="panel">
        <p className="eyebrow">LIVE EVENTS (server-recorded)</p>
        {!view || view.events.length === 0 ? <p className="muted">No events yet.</p> :
          <ol className="timeline">{view.events.map((ev, i) => <li key={i}><time>{new Date(ev.t).toLocaleTimeString()}</time><span className="evtype">{ev.type}</span><span><SafeText text={ev.message} max={300} /></span></li>)}</ol>}
        {view && <ul className="kv">
          <li><span>Request ID</span><b><SafeText as="code" text={view.requestId} max={40} /></b></li>
          <li><span>Local audit</span><b className={view.audit.final === "recorded" || view.audit.decided === "recorded" ? "ok" : "bad"}>{view.audit.final === "recorded" ? "Final record written" : view.audit.decided === "recorded" ? "Decision record written" : "Not written"}</b></li>
          <li><span>Supabase sync</span><b className={sync.state === "saved" ? "ok" : sync.state === "failed" ? "bad" : ""}>{sync.state === "idle" ? "—" : sync.message}</b></li>
        </ul>}
      </div>
    </section>
  );
}
