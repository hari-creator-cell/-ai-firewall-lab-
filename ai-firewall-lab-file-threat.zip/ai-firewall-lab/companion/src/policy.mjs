// Policy decision. Pure function of (scan result, config). Default-deny.
// Nothing from the client can influence this function: it only receives server-produced data.

export function decide(scan, cfg) {
  if (!scan || scan.status !== "ok") {
    return { decision: "block", display: "ERROR", riskLevel: "unknown", reason: "Security scan did not complete; default deny (fail closed).", reasonCode: "scan_failed" };
  }
  if (scan.partialScan) {
    return { decision: "block", display: "BLOCKED", riskLevel: "unknown", reason: "File exceeds the scanner's coverage limit; unscanned content cannot be forwarded.", reasonCode: "partial_scan" };
  }
  const s = scan.riskScore;
  if (s >= cfg.blockThreshold) {
    return { decision: "block", display: "BLOCKED", riskLevel: "high", reason: `Risk score ${s} ≥ block threshold ${cfg.blockThreshold}.`, reasonCode: "risk_high" };
  }
  if (s >= cfg.reviewThreshold) {
    if (cfg.reviewPolicy === "allow") {
      return { decision: "allow", display: "REVIEW", riskLevel: "medium", reason: `Risk score ${s} is in the review band; allowed by REVIEW_POLICY=allow.`, reasonCode: "risk_medium_allowed" };
    }
    return { decision: "block", display: "REVIEW", riskLevel: "medium", reason: `Risk score ${s} is in the review band and REVIEW_POLICY=block holds it for human review.`, reasonCode: "risk_medium_held" };
  }
  return { decision: "allow", display: "ALLOWED", riskLevel: s > 0 ? "low" : "none", reason: `No blocking findings (risk score ${s}). This is not a guarantee of safety.`, reasonCode: "risk_low" };
}
