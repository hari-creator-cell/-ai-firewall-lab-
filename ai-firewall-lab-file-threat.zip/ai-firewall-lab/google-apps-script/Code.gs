/**
 * Google Sheets audit mirror.
 * Deploy as a Web App, execute as your account, and set access to the narrowest
 * option compatible with your deployment. The shared secret is checked server-side.
 * Do not store full prompts, credentials, or sensitive tool arguments here.
 */
const SHEET_NAME = "Firewall Audit";

function doPost(e) {
  const expected = PropertiesService.getScriptProperties().getProperty("WEBHOOK_SECRET");
  let body;
  try { body = JSON.parse((e && e.postData && e.postData.contents) || "{}"); }
  catch (_) { return json({ ok: false, error: "Invalid JSON" }); }

  if (!expected || !body.secret || !constantTimeEquals(String(body.secret), expected)) {
    return json({ ok: false, error: "Unauthorized" });
  }
  const r = body.record || {};
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = spreadsheet.insertSheet(SHEET_NAME);
    sheet.appendRow(["created_at", "request_id", "actor_id", "tool_name", "decision", "reason", "execution_succeeded"]);
    sheet.setFrozenRows(1);
  }
  sheet.appendRow([
    safeCell(r.created_at), safeCell(r.request_id), safeCell(r.actor_id),
    safeCell(r.tool_name), safeCell(r.decision), safeCell(r.reason),
    Boolean(r.execution_succeeded)
  ]);
  return json({ ok: true });
}

function safeCell(value) {
  const s = value == null ? "" : String(value);
  // Prevent spreadsheet formula injection.
  return /^[=+\-@]/.test(s) ? "'" + s : s.slice(0, 1000);
}

function constantTimeEquals(a, b) {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}

function json(value) {
  return ContentService.createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}