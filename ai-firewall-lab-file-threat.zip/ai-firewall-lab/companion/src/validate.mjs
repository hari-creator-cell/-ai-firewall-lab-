// Upload validation + safe text extraction. Only plain-text formats are supported.
// Nothing here executes, renders or fetches anything referenced by the file.
import path from "node:path";

export const SUPPORTED_EXTENSIONS = Object.freeze({
  ".txt": "text", ".md": "markdown", ".csv": "csv", ".json": "json",
  ".log": "text", ".py": "source", ".js": "source", ".ts": "source", ".java": "source",
  ".c": "source", ".cpp": "source", ".go": "source", ".rs": "source", ".sh": "source", ".yaml": "config", ".yml": "config",
});

export class ValidationError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

// Magic-number prefixes of common binary formats we refuse even if renamed to .txt.
const BINARY_SIGNATURES = [
  ["PDF", [0x25, 0x50, 0x44, 0x46]], ["ZIP/Office", [0x50, 0x4b, 0x03, 0x04]], ["PE/EXE", [0x4d, 0x5a]],
  ["ELF", [0x7f, 0x45, 0x4c, 0x46]], ["PNG", [0x89, 0x50, 0x4e, 0x47]], ["JPEG", [0xff, 0xd8, 0xff]],
  ["GIF", [0x47, 0x49, 0x46, 0x38]], ["GZIP", [0x1f, 0x8b]], ["RAR", [0x52, 0x61, 0x72, 0x21]],
  ["OLE/legacy Office", [0xd0, 0xcf, 0x11, 0xe0]], ["Mach-O", [0xcf, 0xfa, 0xed, 0xfe]],
];

/** Reduce an untrusted filename to a display-safe basename. Never used as a filesystem path. */
export function sanitizeFilename(raw) {
  let s = typeof raw === "string" ? raw : "";
  s = s.replace(/\\/g, "/");
  s = s.split("/").pop() ?? "";                 // drop any directory component (path traversal)
  s = s.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, ""); // control + bidi override chars
  s = s.replace(/[<>:"|?*]/g, "_").trim();
  if (s === "" || s === "." || s === "..") s = "unnamed";
  return s.slice(0, 120);
}

export function decodeBase64Strict(b64, maxBytes) {
  if (typeof b64 !== "string" || b64.length === 0) throw new ValidationError("empty_file", "File is empty or missing.");
  if (b64.length > Math.ceil(maxBytes * 4 / 3) + 8) throw new ValidationError("file_too_large", `File exceeds the ${maxBytes} byte limit.`);
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(b64) || b64.length % 4 !== 0) throw new ValidationError("malformed_encoding", "File payload is not valid base64.");
  const buf = Buffer.from(b64, "base64");
  if (buf.length === 0) throw new ValidationError("empty_file", "File is empty.");
  if (buf.length > maxBytes) throw new ValidationError("file_too_large", `File exceeds the ${maxBytes} byte limit.`);
  return buf;
}

/**
 * Validate + extract text. Returns { filename, extension, format, sizeBytes, text, truncated, sha256Prefix? }.
 * Throws ValidationError for anything unsupported, malformed or binary (default-deny).
 */
export function validateAndExtract({ filename, bytes, maxChars }) {
  const safeName = sanitizeFilename(filename);
  const ext = path.extname(safeName).toLowerCase();
  const format = Object.prototype.hasOwnProperty.call(SUPPORTED_EXTENSIONS, ext) ? SUPPORTED_EXTENSIONS[ext] : null;
  if (!format) {
    throw new ValidationError("unsupported_type",
      `Unsupported file type "${ext || "(none)"}". Supported: ${Object.keys(SUPPORTED_EXTENSIONS).join(", ")}.`);
  }
  for (const [name, sig] of BINARY_SIGNATURES) {
    if (sig.every((b, i) => bytes[i] === b)) {
      throw new ValidationError("binary_content", `Content looks like a ${name} file, not plain text. Rejected.`);
    }
  }
  // NUL bytes => binary. Check the whole file (it is small, size-limited).
  if (bytes.includes(0)) throw new ValidationError("binary_content", "File contains NUL bytes and is treated as binary. Rejected.");

  let text;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new ValidationError("malformed_text", "File is not valid UTF-8 text. Rejected.");
  }
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  // Control characters other than \t \n \r are suspicious in "text" files.
  const ctrl = (text.match(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g) || []).length;
  if (ctrl > 0 && ctrl / text.length > 0.02) throw new ValidationError("binary_content", "File contains too many control characters. Rejected.");

  if (format === "json") {
    try { JSON.parse(text); } catch { throw new ValidationError("malformed_json", "File has a .json extension but is not valid JSON."); }
  }
  // Scanner sees everything up to the limit; the model can never receive more than maxChars.
  // If the file is longer than maxChars we do NOT silently forward a prefix: we scan ALL of it,
  // but only the first maxChars are eligible to be sent (and the UI says so).
  return {
    filename: safeName, extension: ext, format, sizeBytes: bytes.length,
    text, truncated: text.length > maxChars,
  };
}
