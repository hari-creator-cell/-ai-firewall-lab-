// Prompt-injection risk scanner. Pure functions, no network, no model calls.
// This is RISK ASSESSMENT: a "clean" result does not prove a file is harmless, and a finding
// is suspicious *text*, not confirmed malware.
//
// Signals:
//   1. deterministic rules (known suspicious patterns)
//   2. context-aware adjustment (quoted/educational discussion, source-code files)
//   3. obfuscation checks (zero-width chars, hidden HTML comments, one level of base64)
//   4. local lexical "attack vocabulary cluster" classifier (no remote service, no LLM)

export const MAX_SCAN_CHARS = 600_000;

const RULES = [
  { id: "instruction_override", category: "Instruction override", weight: 70,
    explain: "Tries to make the model ignore or replace its previous instructions or rules.",
    re: /\b(?:ignore|disregard|forget|override|discard|neglect|set aside)\b[^.\n]{0,40}\b(?:instructions?|rules?|prompts?|guidelines?|polic(?:y|ies)|directives?|constraints?|restrictions?|everything (?:above|before|you (?:were|have been) told))\b/g },
  { id: "instruction_override_everything", category: "Instruction override", weight: 65,
    explain: "Tells the model to forget or discard everything that came before.",
    re: /\b(?:forget|ignore|disregard)\s+(?:everything|all)\s+(?:above|before|prior|previous|earlier|you (?:know|were told))\b/g },
  { id: "new_instructions_marker", category: "Instruction override", weight: 50,
    explain: "Declares 'new/updated instructions' inside document content, a common injection framing.",
    re: /\b(?:new|updated|real|actual|revised)\s+(?:system\s+)?(?:instructions?|directives?|rules?)\s*[:\-]/g },
  { id: "fake_role_marker", category: "Fake system/role markers", weight: 60,
    explain: "Contains chat-template or role markers that imitate system messages.",
    re: /<\|(?:im_start|im_end|system|assistant|user)\|>|\[\/?inst\]|<<\/?sys>>|^\s*#{1,3}\s*system\s*(?:prompt|message)?\s*:|^\s*system\s*:/gm },
  { id: "role_hijack", category: "Role / jailbreak manipulation", weight: 55,
    explain: "Attempts to redefine the model's role or switch it into an unrestricted mode.",
    re: /\byou are now\b|\bdeveloper mode\b|\bjailbreak(?:ed|ing)?\b|\bact as\b[^.\n]{0,30}\b(?:dan|unrestricted|unfiltered|jailbroken)\b|\bwithout (?:any )?(?:restrictions|filters|limitations|guardrails)\b|\bno (?:restrictions|filters|limitations)\b/g },
  { id: "reveal_secrets", category: "Secret / prompt disclosure", weight: 65,
    explain: "Asks the model to reveal confidential instructions, credentials or secrets.",
    re: /\b(?:reveal|disclose|print|show|output|leak|repeat|expose|dump|share|tell me|display)\b[^.\n]{0,50}\b(?:system prompt|hidden (?:instructions?|prompt|configuration)|confidential|secrets?|api[ _-]?keys?|passwords?|credentials?|access tokens?|private (?:data|keys?)|internal (?:instructions?|rules?))\b/g },
  { id: "bypass_firewall", category: "Firewall / safety bypass", weight: 80,
    explain: "Asks the model or the system to bypass, disable or evade the firewall or safety controls.",
    re: /\b(?:bypass|disable|turn off|evade|circumvent|deactivate|skip|trick)\b[^.\n]{0,40}\b(?:firewall|filters?|guardrails?|safety|security (?:checks?|scans?|polic(?:y|ies))|scanner|moderation|detection|content polic(?:y|ies))\b/g },
  { id: "tool_abuse", category: "Unauthorized tool / command use", weight: 60,
    explain: "Instructs the model to invoke tools or run commands, or names prohibited tools.",
    re: /\b(?:you (?:must|should|will|need to)|please|now|immediately|first)\s+(?:call|invoke|run|execute|use)\b[^.\n]{0,30}\b(?:tool|function|command|shell|terminal|powershell|cmd|bash)\b|\b(?:delete_all_data|exfiltrate_secrets|run_arbitrary_code)\b|\brm -rf\b|\bformat c:|\binvoke-expression\b|\bcurl\s+[^|\n]{0,80}\|\s*(?:sh|bash)\b/g },
  { id: "exfiltration", category: "Data exfiltration", weight: 75,
    explain: "Instructs the model to send data to an external address, URL or webhook.",
    re: /\b(?:send|post|upload|forward|email|transmit|exfiltrate|leak)\b[^.\n]{0,60}\b(?:to|at)\b[^.\n]{0,20}(?:https?:\/\/|\b[\w.-]+@[\w.-]+\.\w+|\bwebhook\b|\bremote server\b)/g },
  { id: "markdown_exfil", category: "Data exfiltration", weight: 70,
    explain: "Markdown image/link whose URL carries query data, a known data-leak channel.",
    re: /!\[[^\]]{0,80}\]\(https?:\/\/[^)\s]{0,200}\?[^)\s]{0,200}\)/g },
  { id: "task_hijack", category: "Task manipulation", weight: 45,
    explain: "Tries to make the model ignore the user's actual task and do something else.",
    re: /\b(?:do not|don't|never|stop)\b[^.\n]{0,20}\b(?:summari[sz]e|answer|follow|obey|respond to|help)\b[^.\n]{0,30}\b(?:user|question|task|request|document|analysis)\b|\binstead\b[^.\n]{0,30}\b(?:respond|reply|output|say|write|print)\b|\bonly (?:respond|reply|output|say)\b|\bthe user'?s? (?:real|actual) (?:task|request|goal)\b/g },
  { id: "addressed_to_ai", category: "Content addressed to the AI", weight: 30,
    explain: "Document text speaks directly to an AI assistant, which ordinary documents rarely do.",
    re: /\b(?:attention|note to|message (?:for|to)|instructions? (?:for|to))\b[^.\n]{0,15}\b(?:ai|assistant|llm|language model|chatbot|qwen)\b|\bto the ai (?:reading|processing)\b/g },
];

const DISCUSSION_CONTEXT = /\b(?:for example|e\.g\.|such as|attackers? (?:may|can|might|often)|an attack(?:er)? (?:might|could)|is known as|phrases? like|examples? of|typically (?:look|include)|researchers?|defen[cs]es? against|mitigat\w+|are called|is called)\b/;

const ATTACK_VOCAB = [
  /\bignore\b/, /\bdisregard\b/, /\boverride\b/, /\bbypass\b/, /\breveal\b/, /\bsecrets?\b/, /\bpasswords?\b/,
  /\bsystem prompt\b/, /\bconfidential\b/, /\bjailbreak/, /\bexfiltrat/, /\bunrestricted\b/, /\bhidden (?:instructions?|configuration)\b/,
  /\byou must\b/, /\bdo not tell\b/, /\bset aside\b/, /\bprevious (?:instructions?|rules?)\b/, /\bdisable\b/,
];

// ---------- helpers ----------

export function normalizeForScan(input) {
  let s = String(input).normalize("NFKC");
  s = s.replace(/[\u200b-\u200f\u2060\ufeff\u00ad\u202a-\u202e\u2066-\u2069]/g, ""); // zero-width, soft hyphen, bidi
  // light de-obfuscation of leetspeak between letters, e.g. "1gn0re" -> "ignore"
  s = s.replace(/\b[\w@$]{4,}\b/g, w => (/[a-z]/i.test(w) && /[013@$]/.test(w) ? w.replace(/0/g, "o").replace(/1/g, "i").replace(/3/g, "e").replace(/@/g, "a").replace(/\$/g, "s") : w));
  s = s.replace(/[ \t]+/g, " ");
  return s.toLowerCase();
}

const SECRET_LIKE = /\b(?:sk-[a-z0-9_-]{8,}|eyj[a-z0-9_-]{10,}\.[a-z0-9_-]{10,}\.[a-z0-9_-]{5,}|[a-f0-9]{32,}|ghp_[a-z0-9]{20,}|akia[a-z0-9]{12,})\b/gi;

/** Make an excerpt safe to display/store: single line, control chars removed, secrets redacted, length-limited. */
export function safeExcerpt(text, start, end, max = 160) {
  const pad = 30;
  let s = text.slice(Math.max(0, start - pad), Math.min(text.length, end + pad));
  s = s.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, " ").replace(/\s+/g, " ").trim();
  s = s.replace(SECRET_LIKE, "[REDACTED]");
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

function* matchAll(re, text, cap = 5) {
  const r = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  let m, n = 0;
  while ((m = r.exec(text)) && n < cap) {
    if (m[0].length === 0) { r.lastIndex++; continue; }
    n++;
    yield m;
  }
}

function applyRules(text, { format, origin }) {
  const findings = [];
  for (const rule of RULES) {
    for (const m of matchAll(rule.re, text)) {
      const ctxBefore = text.slice(Math.max(0, m.index - 140), m.index);
      let weight = rule.weight;
      const notes = [];
      if (DISCUSSION_CONTEXT.test(ctxBefore)) { weight = Math.round(weight * 0.5); notes.push("appears inside discussion/example wording; score halved"); }
      if (format === "source" && rule.id === "tool_abuse") { weight = Math.round(weight * 0.5); notes.push("source-code file; score halved"); }
      findings.push({
        ruleId: rule.id, category: rule.category, score: weight, origin,
        explanation: rule.explain + (notes.length ? ` (${notes.join("; ")})` : ""),
        excerpt: safeExcerpt(text, m.index, m.index + m[0].length),
      });
    }
  }
  return findings;
}

function obfuscationChecks(rawText) {
  const out = [];
  const zw = (rawText.match(/[\u200b-\u200f\u2060\ufeff\u202a-\u202e\u2066-\u2069]/g) || []).length;
  if (zw >= 3) out.push({ ruleId: "invisible_chars", category: "Hidden / obfuscated content", score: 30, origin: "raw",
    explanation: `Contains ${zw} invisible or bidirectional-control characters, which can hide instructions from human readers.`, excerpt: `(${zw} invisible characters)` });
  for (const m of matchAll(/<!--([\s\S]{0,2000}?)-->/g, rawText, 3)) {
    if (/\b(?:ignore|instruction|system|assistant|ai|model|secret|reveal|override)\b/i.test(m[1])) {
      out.push({ ruleId: "hidden_comment", category: "Hidden / obfuscated content", score: 40, origin: "raw",
        explanation: "HTML comment containing instruction-like words; comments are invisible when a document is rendered.",
        excerpt: safeExcerpt(rawText, m.index, m.index + m[0].length) });
    }
  }
  return out;
}

function decodedPayloadChecks(rawText, ctx) {
  const out = [];
  for (const m of matchAll(/\b[A-Za-z0-9+/]{32,400}={0,2}(?![A-Za-z0-9+/=])/g, rawText, 3)) {
    let dec = "";
    try { dec = Buffer.from(m[0], "base64").toString("utf8"); } catch { continue; }
    if (!dec || /[^\x09\x0a\x0d\x20-\x7e]/.test(dec)) continue; // must be printable ASCII to be interesting
    const inner = applyRules(normalizeForScan(dec), { ...ctx, origin: "base64" });
    if (inner.length) {
      const top = Math.max(...inner.map(f => f.score));
      out.push({ ruleId: "encoded_payload", category: "Hidden / obfuscated content", score: Math.min(95, top + 15), origin: "base64",
        explanation: "A base64-encoded segment decodes to text that matches injection rules.",
        excerpt: safeExcerpt(dec, 0, Math.min(dec.length, 100)) });
    }
  }
  return out;
}

function clusterSignal(text) {
  // Local lexical classifier: several distinct attack-vocabulary cues inside one 300-char window.
  let best = 0, at = 0;
  const step = 150;
  for (let i = 0; i < text.length; i += step) {
    const win = text.slice(i, i + 300);
    const hits = ATTACK_VOCAB.reduce((n, re) => n + (re.test(win) ? 1 : 0), 0);
    if (hits > best) { best = hits; at = i; }
  }
  if (best >= 3) {
    return [{ ruleId: "attack_vocab_cluster", category: "Heuristic: attack vocabulary cluster", score: Math.min(40, 10 * best), origin: "heuristic",
      explanation: `${best} distinct injection-related terms appear close together. This is a weak statistical signal that can catch paraphrased attacks but also flags some legitimate security writing.`,
      excerpt: safeExcerpt(text, at, at + 200) }];
  }
  return [];
}

/**
 * Scan extracted text. Returns a result object; NEVER throws for content reasons.
 * If something unexpected happens, returns { status:"error" } so the policy layer fails closed.
 */
export function scanText(rawText, { format = "text", maxScanChars = MAX_SCAN_CHARS } = {}) {
  const started = Date.now();
  try {
    if (typeof rawText !== "string") throw new Error("scanner input must be a string");
    const scanned = rawText.length > maxScanChars ? rawText.slice(0, maxScanChars) : rawText;
    const partial = rawText.length > maxScanChars;
    const norm = normalizeForScan(scanned);
    const ctx = { format };
    const findings = [
      ...applyRules(norm, { ...ctx, origin: "text" }),
      ...obfuscationChecks(scanned),
      ...decodedPayloadChecks(scanned, ctx),
      ...clusterSignal(norm),
    ];
    // Deduplicate near-identical findings and order by score.
    findings.sort((a, b) => b.score - a.score);
    const seen = new Set();
    const unique = findings.filter(f => { const k = f.ruleId + "|" + f.excerpt; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 12);
    const top = unique[0]?.score ?? 0;
    const rest = unique.slice(1).reduce((s, f) => s + f.score, 0);
    const riskScore = Math.min(100, Math.round(top + 0.3 * rest));
    return {
      status: "ok", riskScore, findings: unique,
      categories: [...new Set(unique.map(f => f.category))],
      charsScanned: scanned.length, partialScan: partial, durationMs: Date.now() - started,
      disclaimer: "Risk assessment only. A clean result does not prove the file is safe; findings are suspicious text, not confirmed malware.",
    };
  } catch (err) {
    return { status: "error", error: String(err && err.message || err), riskScore: 100, findings: [], categories: [], charsScanned: 0, partialScan: false, durationMs: Date.now() - started };
  }
}
