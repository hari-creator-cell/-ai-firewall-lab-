import { FormEvent, useEffect, useState } from "react";
import { Session } from "@supabase/supabase-js";
import { setupMissing, supabase } from "./lib/supabase";
import FileThreatDetection from "./FileThreatDetection";

type Result = { decision: string; reason: string; actionId?: string; sheetsLogged?: boolean };

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [note, setNote] = useState("Hackathon test action");
  const [action, setAction] = useState("create_demo_note");
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  async function signIn(e: FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMessage(error ? error.message : "Signed in.");
    setBusy(false);
  }

  async function signUp() {
    if (!supabase) return;
    setBusy(true); setMessage("");
    const { error } = await supabase.auth.signUp({ email, password });
    setMessage(error ? error.message : "Account created. If email confirmation is enabled, confirm your email before signing in.");
    setBusy(false);
  }

  async function signOut() {
    if (!supabase) return;
    await supabase.auth.signOut();
    setResult(null); setMessage("Signed out.");
  }

  async function submitAction(e: FormEvent) {
    e.preventDefault();
    if (!supabase || !session?.access_token) return;
    setBusy(true); setResult(null); setMessage("");
    try {
      const response = await fetch("/api/firewall", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${session.access_token}`
        },
        body: JSON.stringify({ tool: action, params: action === "read_demo_status" ? {} : { note } })
      });
      const data = await response.json();
      if (!response.ok && !data.decision) throw new Error(data.error || `Request failed (${response.status})`);
      setResult(data as Result);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Unexpected request error.");
    } finally {
      setBusy(false);
    }
  }

  if (setupMissing) return <main className="shell"><section className="panel"><p className="eyebrow">SETUP REQUIRED</p><h1>AI Firewall Lab</h1><p>Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> to your local <code>.env.local</code> file and Vercel project environment variables.</p></section><FileThreatDetection session={null} /></main>;

  return <main className="shell">
    <header className="topbar"><div className="brand-mark">AF</div><div><p className="eyebrow">HACKATHON MVP</p><h1>AI Firewall Lab</h1></div><span className="status"><i /> Gateway prototype</span></header>
    <section className="hero"><div><p className="eyebrow">POLICY-ENFORCED TOOL ACCESS</p><h2>Make every tool request<br /><span>earn its permission.</span></h2><p className="muted">Requests are checked by a server-side Vercel API against Supabase policies. Decisions are stored in Supabase and optionally copied to Google Sheets.</p></div><div className="shield-art">⌁<div>SECURE<br/>GATEWAY</div></div></section>

    {!session ? <section className="panel auth-panel"><div><p className="eyebrow">IDENTITY</p><h3>Sign in to test the gateway</h3><p className="muted">Create a test account for your hackathon project.</p></div><form onSubmit={signIn} className="stack"><label>Email<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} /></label><label>Password<input type="password" autoComplete="current-password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} /></label><div className="button-row"><button disabled={busy} type="submit">Sign in</button><button disabled={busy} type="button" className="secondary" onClick={signUp}>Create account</button></div>{message && <p className="notice">{message}</p>}</form></section> :
    <><section className="user-row"><div><p className="eyebrow">AUTHENTICATED SESSION</p><strong>{session.user.email}</strong></div><button className="secondary small" onClick={signOut}>Sign out</button></section>
      <section className="workspace"><div className="panel request-panel"><p className="eyebrow">REQUEST TOOL ACCESS</p><h3>Try a controlled action</h3><p className="muted">The server independently checks the selected tool against the policy table. The browser cannot grant permission.</p>
        <form onSubmit={submitAction} className="stack"><label>Tool action<select value={action} onChange={e=>setAction(e.target.value)}><option value="create_demo_note">Create demo note (allowed test action)</option><option value="delete_all_data">Delete all data (hard-deny test)</option><option value="read_demo_status">Read demo status</option><option value="unknown_tool">Unknown tool (default-deny test)</option></select></label><label>Test note<input value={note} maxLength={200} onChange={e=>setNote(e.target.value)} /></label><button disabled={busy} type="submit">{busy ? "Checking policy…" : "Submit request"}</button></form>
      </div><div className="panel result-panel"><p className="eyebrow">LATEST DECISION</p>{!result ? <div className="empty"><div className="empty-icon">✓</div><h3>Awaiting request</h3><p className="muted">Submit a request to see the server's decision and execution result.</p></div> : <><span className={`decision ${result.decision === "allow" ? "allow" : "deny"}`}>{result.decision.toUpperCase()}</span><h3>{result.reason}</h3>{result.actionId && <p className="muted">Execution record: <code>{result.actionId}</code></p>}<div className="log-status"><span>Supabase decision log</span><b>Recorded by gateway</b></div><div className="log-status"><span>Google Sheets mirror</span><b>{result.sheetsLogged ? "Sent" : "Not confirmed"}</b></div></>}</div></section>
    </>}
    <FileThreatDetection session={session} />
    {message && session && <p className="notice global-notice">{message}</p>}
    <footer><span>AI Firewall Lab · MVP</span><span>Server-side authorization · Default deny</span></footer>
  </main>;
}