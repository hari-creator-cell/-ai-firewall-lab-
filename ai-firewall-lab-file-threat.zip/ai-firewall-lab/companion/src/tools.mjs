// Server-side tool gateway. The model can never authorize its own actions: every tool call it
// emits is checked here against (a) the request's lifecycle state and (b) a hard-coded policy.
// Tools are intentionally tiny and local (in-memory); there is no shell, file, or network tool.

export const ALLOWED_TOOLS = Object.freeze({
  create_demo_note: { params: ["note"], validate: p => typeof p.note === "string" && p.note.trim().length >= 1 && p.note.length <= 200 },
  read_demo_status: { params: [], validate: p => Object.keys(p).length === 0 },
});
export const HARD_DENIED_TOOLS = Object.freeze(new Set(["delete_all_data", "exfiltrate_secrets", "run_arbitrary_code", "run_shell", "execute_command"]));

export const TOOL_DEFINITIONS = [
  { type: "function", function: { name: "create_demo_note", description: "Store a short demo note (max 200 chars).", parameters: { type: "object", properties: { note: { type: "string" } }, required: ["note"] } } },
  { type: "function", function: { name: "read_demo_status", description: "Return how many demo notes exist.", parameters: { type: "object", properties: {} } } },
];

export function createToolGateway({ enabled = false } = {}) {
  const notes = [];
  /**
   * @param ctx request record: must expose { id, cancelled, decision }
   * @returns { allowed, executed, reason, result? }  (never throws; every path is deny-by-default)
   */
  function authorizeAndRun(ctx, call) {
    const deny = reason => ({ allowed: false, executed: false, reason });
    try {
      if (!ctx || ctx.cancelled === true || ctx.state === "cancelled") return deny("Request was cancelled; tool execution refused.");
      if (ctx.decision !== "allow") return deny("Request was not allowed by the firewall; tool execution refused.");
      const name = call && typeof call.name === "string" ? call.name : "";
      if (HARD_DENIED_TOOLS.has(name)) return deny(`Tool "${name}" is hard-denied.`);
      if (!enabled) return deny("Model tool calls are disabled (ENABLE_MODEL_TOOLS=false).");
      if (!Object.prototype.hasOwnProperty.call(ALLOWED_TOOLS, name)) return deny(`Tool "${name}" is not in the allowlist.`);
      const spec = ALLOWED_TOOLS[name];
      let params = call.arguments;
      if (typeof params === "string") { try { params = JSON.parse(params); } catch { return deny("Tool arguments are not valid JSON."); } }
      if (!params || typeof params !== "object" || Array.isArray(params)) return deny("Tool arguments must be an object.");
      if (Object.keys(params).some(k => !spec.params.includes(k))) return deny("Tool arguments contain parameters outside the policy.");
      if (!spec.validate(params)) return deny("Tool arguments failed validation.");
      // Last check immediately before the side effect (no await between this and execution).
      if (ctx.cancelled === true || ctx.state === "cancelled") return deny("Request was cancelled; tool execution refused.");
      if (name === "create_demo_note") {
        if (notes.length >= 100) notes.shift();
        notes.push({ requestId: ctx.id, note: params.note.trim(), at: new Date().toISOString() });
        return { allowed: true, executed: true, reason: "Matched allowlist policy.", result: { stored: true } };
      }
      return { allowed: true, executed: true, reason: "Matched allowlist policy.", result: { demoNotes: notes.length } };
    } catch (err) {
      return deny("Tool gateway error; default deny.");
    }
  }
  return { authorizeAndRun, notesCount: () => notes.length, enabled };
}
