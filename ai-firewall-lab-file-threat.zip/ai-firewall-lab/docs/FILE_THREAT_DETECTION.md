# File Threat Detection — setup, demo and security notes

## Architecture

```
Browser (Vercel site or http://localhost:5173)
   │  JSON over loopback, pairing token + Origin allowlist
   ▼
Local companion  (companion/, Node, zero npm deps, 127.0.0.1:8787)
   Upload → Validation → Extraction → Firewall scan → Policy decision ─┬─ block → audit (Ollama never contacted)
                                                                       └─ allow → audit "decided" → Ollama /api/chat → audit "final"
   ▼ (only for allowed requests)
Ollama  http://localhost:11434   model qwen3:1.7b
```

* A Vercel function cannot reach your laptop's `localhost`, so enforcement runs in the **companion on your laptop**. The browser talks to the companion; only the companion talks to Ollama. Port 11434 is never exposed.
* Two-step API: `POST /v1/requests` (validate + scan + decide; the server keeps the text in memory) and `POST /v1/requests/:id/run` (accepts only a request id + task text). There is no endpoint that takes arbitrary text/model parameters, so the scan cannot be skipped. Fields such as `allow`/`safe` in a request are never read.
* Audit: every decision is written to `companion/data/audit.jsonl` (hashes/metadata only — no document text, prompt or answer). If the pre-inference audit write fails, the file is **blocked** (fail closed). Optional signed sync to Supabase table `file_scan_audit` through `api/file-audit.ts`; the UI reports sync success/failure from the real response.

## Windows setup (ASUS TUF A15)

Prerequisites: Node.js 20+ and Ollama with `qwen3:1.7b` already installed (nothing is downloaded by these scripts).

```powershell
cd path\to\ai-firewall-lab
powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
```

Run the demo (Terminal 1 or just this script):

```powershell
ollama list                      # confirm qwen3:1.7b is listed; Ollama app/service must be running
powershell -ExecutionPolicy Bypass -File scripts\run.ps1
```

This starts the Vite UI (http://localhost:5173) in a new window and the companion in the current one. Copy the **PAIRING TOKEN** printed by the companion into *File Threat Detection → Companion connection → Connect*. To keep a stable token, set `COMPANION_SESSION_TOKEN` in `companion/.env`.

Using the deployed Vercel site instead: add its URL to `ALLOWED_ORIGINS` in `companion/.env`, restart the companion, run `run.ps1 -NoUi`, and use **Chrome or Edge** (they allow HTTPS pages to call `http://127.0.0.1`; Chrome may show a "local network access" prompt — accept it). Safari/Firefox may block this; use the localhost UI there.

Supabase audit sync (optional): run `supabase/migrations/001_file_scan_audit.sql` (additive, one new table), set the same random `AUDIT_SYNC_SECRET` in Vercel env vars and `companion/.env`, redeploy.

## Demo script

1. Start Ollama, run `scripts\run.ps1`, pair the token. Model status should show *Connected / Installed*.
2. `companion/samples/scenario-a-safe.txt` → **SAFE / ALLOWED**, Qwen's real answer appears, events show `model_request_started`.
3. `scenario-b-injection.txt` → **BLOCKED**, findings with explanations, "Sent to Qwen: No". Confirm: companion console / `Get-Content companion\data\audit.jsonl -Tail 2` shows `"ollama_invoked":false`. (Optionally watch Ollama's log; no request arrives.)
4. `scenario-c-unsupported.bin` → rejected at validation.
5. Scenario D: quit Ollama, upload the safe file → clear "Ollama not reachable" error, no response claimed.
6. Scenario E: upload the safe file and press **■ Emergency Stop** while "Qwen is working…" → state `cancelled`, response discarded, cancellation logged, any later tool call refused.

## Tests

```powershell
npm test                 # companion tests + UI escape tests
npm run test:ollama      # real Ollama integration (auto-skips if Ollama/model unavailable)
```

See the verification table in the delivery notes for what was actually executed.

## Known limitations and caveats

* **Detection is heuristic.** Regex rules, a lexical cluster signal and base64/zero-width checks catch common injection phrasing, not every paraphrase, other languages, or novel obfuscation. A clean result is not proof of safety. Wording such as "for example, ignore previous instructions" halves the score (so security write-ups can pass); an attacker could abuse that. Strict policy holds REVIEW-band files by default.
* Findings are suspicious **text**, not malware verdicts. Only plain-text formats are supported; PDF/DOCX/images/archives are rejected, not scanned.
* The model's output is untrusted; it is displayed as text only. Qwen3 1.7B can still be manipulated by content below the block threshold.
* **Emergency Stop** aborts the companion's HTTP request to Ollama, discards the result and permanently disables tool execution for that request. It does not prove Ollama stopped computing.
* Model tool calls are disabled by default; the demo tools are in-memory only. Tool calling with a 1.7B model is unreliable, so Scenario E is demonstrated mainly through inference cancellation plus unit tests of the gateway.
* Pairing token is a local session secret held in `sessionStorage`; anything running on your PC as your user could read the console or audit file. Not a defence against a compromised laptop.
* Supabase sync trusts any record signed with `AUDIT_SYNC_SECRET`; a signed record could be submitted by any signed-in user who has it. `request_id` uniqueness prevents duplicates.
* No temp files are created (uploads live in memory only and are dropped when a request finishes), so there is nothing to clean up on disk except the audit file.
* Ollama `think:false` needs a reasonably recent Ollama; older versions ignore it and any `<think>` text is stripped.
