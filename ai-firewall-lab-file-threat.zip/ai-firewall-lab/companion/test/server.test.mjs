import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { readFileSync } from "node:fs";
import { startMockOllama, startCompanion, SAFE_DOC, INJECTION_DOC } from "./helpers.mjs";
import { createToolGateway } from "../src/tools.mjs";
import { verifySignature } from "../src/audit.mjs";

const sleep = ms => new Promise(r => setTimeout(r, ms));
const auditLines = c => readFileSync(c.cfg.auditFile, "utf8").split("\n").filter(Boolean).map(l => JSON.parse(l));

async function withStack(opts, fn) {
  const ollama = await startMockOllama(opts.ollama);
  const c = await startCompanion({ ollamaUrl: opts.ollamaUrl ?? ollama.url, env: opts.env, audit: opts.audit });
  try { await fn({ ollama, c }); } finally { await c.close(); await ollama.close(); }
}

test("allowed file: scanned, forwarded to the model, real response returned, audit + events recorded", async () => {
  await withStack({}, async ({ ollama, c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    assert.equal(up.status, 200);
    assert.equal(up.json.decision, "allow");
    assert.equal(up.json.state, "ready");
    assert.equal(ollama.chatCalls().length, 0, "scan must complete before any chat call");
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, { prompt: "Summarize" });
    assert.equal(run.json.state, "completed");
    assert.equal(run.json.response.text, "MOCK SUMMARY");
    assert.equal(run.json.forwardedToModel, true);
    const chat = ollama.chatCalls();
    assert.equal(chat.length, 1);
    assert.equal(chat[0].body.model, "qwen3:1.7b");
    assert.equal(chat[0].body.stream, false);
    assert.ok(chat[0].body.messages[1].content.includes(SAFE_DOC));
    const types = run.json.events.map(e => e.type);
    assert.deepEqual(types.filter(t => ["upload_received", "validation_completed", "scan_completed", "firewall_decision", "model_request_started", "model_response_completed"].includes(t)),
      ["upload_received", "validation_completed", "scan_completed", "firewall_decision", "model_request_started", "model_response_completed"]);
    const lines = auditLines(c).filter(l => l.request_id === up.json.requestId);
    assert.deepEqual(lines.map(l => l.stage), ["decided", "final"]);
    assert.equal(lines[1].final_status, "completed");
    assert.equal(lines[1].ollama_invoked, true);
    assert.equal(lines[1].decision, "allow");
  });
});

test("blocked file never triggers an Ollama chat request; client-supplied allow flags are ignored; /run is refused", async () => {
  await withStack({}, async ({ ollama, c }) => {
    const up = await c.upload("inj.txt", INJECTION_DOC, { allow: true, safe: true, decision: "allow", policy: { decision: "allow" } });
    assert.equal(up.json.decision, "block");
    assert.equal(up.json.state, "blocked");
    assert.equal(up.json.forwardedToModel, false);
    assert.ok(up.json.scan.findings.length > 0);
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, { prompt: "x", allow: true });
    assert.equal(run.status, 409);
    assert.equal(ollama.chatCalls().length, 0);
    assert.equal(ollama.calls.filter(x => x.url === "/api/chat").length, 0);
    const final = auditLines(c).find(l => l.request_id === up.json.requestId && l.stage === "final");
    assert.equal(final.decision, "block");
    assert.equal(final.ollama_invoked, false);
    assert.ok(final.detection_categories.length > 0);
    assert.ok(up.json.events.some(e => e.type === "model_request_skipped"));
  });
});

test("unsupported, oversized and malformed uploads are rejected before inference and audited", async () => {
  await withStack({ env: { MAX_FILE_BYTES: "2000" } }, async ({ ollama, c }) => {
    const bad = [
      c.upload("evil.exe", "MZ"), c.upload("big.txt", "a".repeat(3000)), c.upload("x.txt", Buffer.from([0, 1, 2, 3])),
      c.api("POST", "/v1/requests", { filename: "a.txt", contentBase64: "***" }), c.api("POST", "/v1/requests", { filename: "a.txt" }),
      c.upload("a.json", "{oops"),
    ];
    for (const r of await Promise.all(bad)) {
      assert.equal(r.json.state, "rejected", JSON.stringify(r.json));
      assert.equal(r.json.decision, "block");
      assert.equal(r.json.forwardedToModel, false);
    }
    assert.equal(ollama.chatCalls().length, 0);
    assert.equal(ollama.calls.length, 0, "rejection must not even contact Ollama");
    const finals = auditLines(c).filter(l => l.stage === "final");
    assert.equal(finals.length, 6);
    assert.ok(finals.every(l => l.final_status === "rejected" && l.ollama_invoked === false));
  });
});

test("malformed request bodies are handled safely", async () => {
  await withStack({}, async ({ c }) => {
    const raw = (body, ctype = "application/json") => fetch(c.base + "/v1/requests", { method: "POST", headers: { Authorization: "Bearer test-token", "Content-Type": ctype }, body });
    assert.equal((await raw("{not json")).status, 400);
    assert.equal((await raw("[1,2]")).status, 400);
    assert.equal((await raw("x=1", "text/plain")).status, 415);
  });
});

test("oversized request bodies are refused (413)", async () => {
  await withStack({ env: { MAX_BODY_BYTES: "5000" } }, async ({ c }) => {
    const status = await new Promise((resolve, reject) => {
      const req = http.request(c.base + "/v1/requests", { method: "POST", headers: { Authorization: "Bearer test-token", "Content-Type": "application/json", "Content-Length": 100000 } }, res => { res.resume(); resolve(res.statusCode); });
      req.on("error", reject); req.end("x".repeat(100000));
    });
    assert.equal(status, 413);
  });
});

test("Ollama unavailable: clear error, nothing claimed as processed, content never sent", async () => {
  await withStack({ ollamaUrl: "http://127.0.0.1:1" }, async ({ c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    assert.equal(up.json.decision, "allow");
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.json.state, "error");
    assert.equal(run.json.error.code, "ollama_unreachable");
    assert.equal(run.json.response, null);
    assert.equal(run.json.forwardedToModel, false);
    assert.ok(run.json.events.some(e => e.type === "model_request_skipped"));
    const st = await c.api("GET", "/v1/status");
    assert.equal(st.json.ollama.reachable, false);
  });
});

test("model missing, HTTP error, malformed response and timeout are reported, not faked", async () => {
  await withStack({ ollama: { models: ["llama3:8b"] } }, async ({ c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.json.error.code, "model_missing");
    assert.equal(run.json.forwardedToModel, false);
  });
  for (const [name, chat, code] of [
    ["malformed", () => ({ nope: true }), "bad_response"],
    ["500", (_b, _q, res) => { res.statusCode = 500; res.end(JSON.stringify({ error: "boom" })); }, "http_error"],
  ]) {
    await withStack({ ollama: { chat } }, async ({ c }) => {
      const up = await c.upload("safe.txt", SAFE_DOC);
      const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
      assert.equal(run.json.state, "error", name);
      assert.equal(run.json.error.code, code, name);
      assert.equal(run.json.response, null);
    });
  }
  await withStack({ env: { OLLAMA_TIMEOUT_MS: "300" }, ollama: { chat: async () => { await sleep(1500); return undefined; } } }, async ({ c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.json.error.code, "timeout");
  });
});

test("Emergency Stop: running request is cancelled, response discarded, no tool executes", async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  await withStack({
    env: { ENABLE_MODEL_TOOLS: "true" },
    ollama: { chat: async () => { await Promise.race([gate, sleep(4000)]); return { model: "qwen3:1.7b", done: true,
      message: { role: "assistant", content: "late", tool_calls: [{ function: { name: "create_demo_note", arguments: { note: "should never be stored" } } }] } }; } },
  }, async ({ ollama, c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    const running = c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    for (let i = 0; i < 50 && ollama.chatCalls().length === 0; i++) await sleep(20);
    assert.equal(ollama.chatCalls().length, 1, "chat request should be in flight");
    const cancel = await c.api("POST", `/v1/requests/${up.json.requestId}/cancel`);
    assert.equal(cancel.json.state, "cancelled");
    assert.match(cancel.json.cancelNote, /NOT verified/);
    const run = await running;
    release();
    await sleep(100);
    assert.equal(run.json.state, "cancelled");
    assert.equal(run.json.response, null);
    assert.equal(run.json.toolCalls.length, 0);
    assert.equal(c.app.tools.notesCount(), 0, "no tool may execute after cancel");
    assert.ok(run.json.events.some(e => e.type === "request_cancelled"));
    const again = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(again.status, 409);
    const final = auditLines(c).filter(l => l.request_id === up.json.requestId && l.stage === "final");
    assert.equal(final.length, 1);
    assert.equal(final[0].final_status, "cancelled");
  });
});

test("Emergency Stop before running: cancelled request cannot start inference", async () => {
  await withStack({}, async ({ ollama, c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    const cancel = await c.api("POST", `/v1/requests/${up.json.requestId}/cancel`);
    assert.equal(cancel.json.state, "cancelled");
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.status, 409);
    assert.equal(ollama.chatCalls().length, 0);
  });
});

test("tool gateway: cancelled/blocked contexts and disabled tools never execute; allowed tool works as positive control", () => {
  const gw = createToolGateway({ enabled: true });
  const call = { name: "create_demo_note", arguments: { note: "hi" } };
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow", cancelled: true }, call).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow", state: "cancelled" }, call).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "block" }, call).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow" }, { name: "run_arbitrary_code", arguments: {} }).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow" }, { name: "unknown", arguments: {} }).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow" }, { name: "create_demo_note", arguments: { note: "x", extra: 1 } }).executed, false);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow" }, { name: "create_demo_note", arguments: { note: "x".repeat(201) } }).executed, false);
  assert.equal(gw.notesCount(), 0);
  assert.equal(gw.authorizeAndRun({ id: "1", decision: "allow" }, call).executed, true);
  assert.equal(gw.notesCount(), 1);
  assert.equal(createToolGateway({ enabled: false }).authorizeAndRun({ id: "1", decision: "allow" }, call).executed, false);
});

test("model-emitted tool calls are policy-checked (denied when tools disabled, even for allowed requests)", async () => {
  await withStack({ ollama: { chat: () => ({ model: "m", done: true, message: { role: "assistant", content: "ok", tool_calls: [{ function: { name: "delete_all_data", arguments: {} } }] } }) } }, async ({ c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.json.state, "completed");
    assert.equal(run.json.toolCalls[0].executed, false);
    assert.equal(c.app.tools.notesCount(), 0);
  });
});

test("fail closed: audit trail failure on an allowed file blocks it before inference", async () => {
  const failing = { file: "x", write: async () => ({ ok: false, error: "EACCES" }), recent: async () => [] };
  await withStack({ audit: failing }, async ({ ollama, c }) => {
    const up = await c.upload("safe.txt", SAFE_DOC);
    assert.equal(up.json.decision, "block");
    assert.equal(up.json.policy.reasonCode, "audit_unavailable");
    assert.equal(up.json.audit.decided, "failed");
    assert.ok(up.json.events.some(e => e.type === "audit_failed"));
    assert.ok(!up.json.events.some(e => e.type === "audit_recorded"), "must not claim a log was saved");
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, {});
    assert.equal(run.status, 409);
    assert.equal(ollama.chatCalls().length, 0);
  });
});

test("companion cannot be used to bypass the firewall (auth, origin, host, no raw-model endpoints)", async () => {
  await withStack({}, async ({ ollama, c }) => {
    assert.equal((await c.api("POST", "/v1/requests", { filename: "a.txt", contentBase64: "aGk=" }, { token: null })).status, 401);
    assert.equal((await c.api("GET", "/v1/status", undefined, { token: "wrong" })).status, 401);
    for (const p of ["/v1/chat", "/api/chat", "/api/generate", "/v1/generate", "/v1/analyze", "/v1/models"]) {
      assert.equal((await c.api("POST", p, { prompt: "hi", model: "qwen3:1.7b", messages: [] })).status, 404, p);
    }
    assert.equal((await c.api("POST", "/v1/requests/00000000-0000-0000-0000-000000000000/run", {})).status, 404);
    const bad = await c.api("GET", "/v1/ping", undefined, { headers: { Origin: "https://evil.example" } });
    assert.equal(bad.status, 403);
    const ok = await c.api("GET", "/v1/ping", undefined, { headers: { Origin: "http://localhost:5173" } });
    assert.equal(ok.status, 200);
    assert.equal(ok.headers.get("access-control-allow-origin"), "http://localhost:5173");
    const host = await new Promise((resolve, reject) => {
      const req = http.request(c.base + "/v1/ping", { headers: { Host: "evil.example" } }, res => { res.resume(); resolve(res.statusCode); });
      req.on("error", reject); req.end();
    });
    assert.equal(host, 403, "DNS-rebinding style Host header must be refused");
    assert.equal(ollama.calls.length, 0);
    // request views never expose document text
    const up = await c.upload("safe.txt", SAFE_DOC);
    assert.ok(!JSON.stringify(up.json).includes(SAFE_DOC));
  });
});

test("companion refuses to bind to non-loopback hosts by default", async () => {
  const { loadConfig } = await import("../src/config.mjs");
  assert.throws(() => loadConfig({ COMPANION_HOST: "0.0.0.0" }), /non-loopback/);
  assert.doesNotThrow(() => loadConfig({ COMPANION_HOST: "127.0.0.1" }));
});

test("audit records contain no document text or prompt and sign correctly for Supabase sync", async () => {
  await withStack({ env: { AUDIT_SYNC_SECRET: "s3cret-for-test" } }, async ({ c }) => {
    const up = await c.upload("my-private-name.txt", SAFE_DOC);
    await c.api("POST", `/v1/requests/${up.json.requestId}/run`, { prompt: "PROMPT-SENTINEL-123" });
    const raw = readFileSync(c.cfg.auditFile, "utf8");
    assert.ok(!raw.includes(SAFE_DOC) && !raw.includes("PROMPT-SENTINEL-123") && !raw.includes("MOCK SUMMARY") && !raw.includes("my-private-name"));
    const a = await c.api("GET", `/v1/requests/${up.json.requestId}/audit`);
    assert.equal(a.json.record.final_status, "completed");
    assert.ok(verifySignature(a.json.record, a.json.signature, "s3cret-for-test"));
    assert.ok(!verifySignature({ ...a.json.record, decision: "block" }, a.json.signature, "s3cret-for-test"));
  });
});

test("concurrency limit: second simultaneous inference is refused", async () => {
  await withStack({ ollama: { chat: async () => { await sleep(400); return undefined; } } }, async ({ c }) => {
    const a = await c.upload("a.txt", SAFE_DOC), b = await c.upload("b.txt", SAFE_DOC);
    const first = c.api("POST", `/v1/requests/${a.json.requestId}/run`, {});
    await sleep(100);
    const second = await c.api("POST", `/v1/requests/${b.json.requestId}/run`, {});
    assert.equal(second.status, 429);
    assert.equal((await first).json.state, "completed");
  });
});
