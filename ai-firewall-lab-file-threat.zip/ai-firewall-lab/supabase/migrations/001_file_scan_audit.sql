-- ADDITIVE migration for File Threat Detection. Creates one NEW table; does not touch existing tables or rows.
-- Run in the Supabase SQL Editor. Safe to re-run.
create table if not exists public.file_scan_audit (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique,
  actor_id uuid not null references auth.users(id) on delete cascade,
  local_actor text,
  file_id text,                       -- hash of filename + extension; never the filename or content
  file_size integer,
  detected_format text,
  scan_status text,
  risk_score integer,
  detection_categories text[] not null default '{}',
  decision text not null check (decision in ('allow', 'block')),
  reason_code text,
  ollama_invoked boolean not null default false,
  model text,
  final_status text,
  tool_calls jsonb not null default '[]',
  created_at timestamptz,
  synced_at timestamptz not null default now()
);

alter table public.file_scan_audit enable row level security;
revoke all on public.file_scan_audit from anon, authenticated;
grant select on public.file_scan_audit to authenticated;

drop policy if exists "users can read own file scan audit" on public.file_scan_audit;
create policy "users can read own file scan audit"
on public.file_scan_audit for select to authenticated
using ((select auth.uid()) = actor_id);
-- Inserts happen only from api/file-audit.ts using the service-role key (bypasses RLS).

create index if not exists file_scan_audit_actor_created_idx on public.file_scan_audit (actor_id, synced_at desc);
