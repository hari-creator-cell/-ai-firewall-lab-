// Browser client for the LOCAL companion service. The browser never talks to Ollama directly,
// and it never decides allow/block: it only displays what the companion's server-side pipeline returns.

export type EventItem = { t: string; type: string; message: string };
export type Finding = { ruleId: string; category: string; score: number; explanation: string; excerpt: string };
export type RequestView = {
  requestId: string; state: string; createdAt: string;
  file: { filename: string; sizeBytes: number | null; format: string | null; extension: string; truncatedForModel: boolean } | null;
  scan: { status: string; riskScore: number; categories: string[]; charsScanned: number; durationMs: number; disclaimer: string; findings: Finding[] } | null;
  policy: { decision: string; display: string; riskLevel: string; reason: string; reasonCode: string } | null;
  decision: string; forwardedToModel: boolean; forwardedChars: number; model: string;
  response: { text: string; truncated: boolean; model: string; doneReason: string | null; totalDurationMs: number | null } | null;
  error: { code: string; message: string } | null;
  toolCalls: { name: string; allowed: boolean; executed: boolean; reason: string }[];
  cancelNote: string | null;
  audit: { decided: string; final: string; store: string };
  events: EventItem[];
};
export type StatusView = {
  companion: string; model: string; activeInference: number; supportedExtensions: string[]; reviewPolicy: string; modelToolsEnabled: boolean; auditSigning: boolean;
  limits: { maxFileBytes: number; maxExtractedChars: number; maxPromptChars: number };
  ollama: { reachable: boolean; modelAvailable: boolean; model: string; installedModels: string[]; error: string | null; checkedAt: string };
};

export class CompanionError extends Error {
  status: number;
  constructor(message: string, status = 0) { super(message); this.status = status; }
}

export function createCompanionClient(baseUrl: string, token: string) {
  const base = baseUrl.replace(/\/+$/, "");
  async function call<T>(method: string, path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
    let res: Response;
    try {
      res = await fetch(base + path, {
        method, signal,
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body !== undefined ? { "Content-Type": "application/json" } : {}) },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") throw err;
      throw new CompanionError("Cannot reach the local companion service. Is it running (and is this browser allowed to call localhost)?");
    }
    let data: unknown = null;
    try { data = await res.json(); } catch { /* non-JSON */ }
    if (!res.ok) {
      const msg = data && typeof data === "object" && "error" in data ? String((data as { error: unknown }).error) : `Companion returned HTTP ${res.status}`;
      throw new CompanionError(msg, res.status);
    }
    return data as T;
  }
  return {
    ping: () => call<{ service: string; version: string }>("GET", "/v1/ping"),
    status: () => call<StatusView>("GET", "/v1/status"),
    submit: (filename: string, contentBase64: string) => call<RequestView>("POST", "/v1/requests", { filename, contentBase64 }),
    run: (id: string, prompt: string, signal?: AbortSignal) => call<RequestView>("POST", `/v1/requests/${id}/run`, { prompt }, signal),
    get: (id: string) => call<RequestView>("GET", `/v1/requests/${id}`),
    cancel: (id: string) => call<RequestView>("POST", `/v1/requests/${id}/cancel`, {}),
    auditExport: (id: string) => call<{ record: Record<string, unknown>; signature: string | null; localAudit: string }>("GET", `/v1/requests/${id}/audit`),
  };
}

export async function fileToBase64(file: File): Promise<string> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
