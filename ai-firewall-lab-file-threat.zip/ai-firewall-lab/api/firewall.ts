import { createClient } from "@supabase/supabase-js";

type VercelRequest = { method?: string; headers: Record<string, string | string[] | undefined>; body: unknown };
type VercelResponse = { setHeader(name: string, value: string): void; status(code: number): VercelResponse; json(body: unknown): unknown };

const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const sheetsUrl = process.env.SHEETS_WEBHOOK_URL;
const sheetsSecret = process.env.SHEETS_WEBHOOK_SECRET;

const allowedTools = new Set(["create_demo_note", "read_demo_status"]);
const hardDeniedTools = new Set(["delete_all_data", "exfiltrate_secrets", "run_arbitrary_code"]);

function response(res: VercelResponse, status: number, body: unknown) {
  return res.status(status).json(body);
}

async function mirrorToSheets(record: Record<string, unknown>): Promise<boolean> {
  if (!sheetsUrl || !sheetsSecret) return false;
  try {
    const r = await fetch(sheetsUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ secret: sheetsSecret, record })
    });
    return r.ok;
  } catch {
    return false;
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return response(res, 405, { error: "Method not allowed" });
  if (!supabaseUrl || !serviceKey) return response(res, 500, { error: "Server is missing Supabase configuration" });

  const rawAuthorization = req.headers.authorization;
  const authorization = Array.isArray(rawAuthorization) ? rawAuthorization[0] : rawAuthorization;
  if (typeof authorization !== "string" || !authorization.startsWith("Bearer ")) {
    return response(res, 401, { error: "Missing bearer token" });
  }
  const accessToken = authorization.slice("Bearer ".length);
  const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await db.auth.getUser(accessToken);
  if (authError || !authData.user) return response(res, 401, { error: "Invalid or expired session" });
  const actor = authData.user.id;

  const body = req.body as { tool?: unknown; params?: unknown };
  if (!body || typeof body.tool !== "string" || !body.params || typeof body.params !== "object" || Array.isArray(body.params)) {
    return response(res, 400, { error: "Expected { tool: string, params: object }" });
  }
  const tool = body.tool;
  const params = body.params as Record<string, unknown>;
  if (JSON.stringify(body).length > 5000) return response(res, 413, { error: "Request too large" });

  let decision: "allow" | "deny" = "deny";
  let reason = "Default deny: no matching allow policy";
  let actionId: string | undefined;

  if (hardDeniedTools.has(tool)) {
    reason = "Hard-deny rule: this action is prohibited";
  } else if (!allowedTools.has(tool)) {
    reason = "Unknown tool: not in the server allowlist";
  } else {
    const { data: policy, error: policyError } = await db
      .from("tool_policies")
      .select("enabled, requires_approval, allowed_params")
      .eq("tool_name", tool)
      .maybeSingle();

    if (policyError) {
      reason = "Policy lookup failed; default deny";
    } else if (!policy || !policy.enabled) {
      reason = "No enabled policy for this tool; default deny";
    } else if (policy.requires_approval) {
      reason = "Approval required; approval workflow is not enabled in this MVP";
    } else {
      const allowedParams = Array.isArray(policy.allowed_params) ? policy.allowed_params as string[] : [];
      const extraKeys = Object.keys(params).filter(k => !allowedParams.includes(k));
      if (extraKeys.length) {
        reason = "Request contains parameters not permitted by the policy";
      } else if (tool === "create_demo_note" && (typeof params.note !== "string" || params.note.trim().length < 1 || params.note.length > 200)) {
        reason = "Invalid note: must be 1–200 characters";
      } else if (tool === "read_demo_status" && Object.keys(params).length !== 0) {
        reason = "read_demo_status accepts no parameters";
      } else {
        decision = "allow";
        reason = "Matched enabled server policy";
      }
    }
  }

  const requestId = crypto.randomUUID();
  let executionResult: Record<string, unknown> | null = null;
  let executionSucceeded = false;

  // Persist an intent record BEFORE executing an allowed action. If this insert
  // fails, no tool is executed. "pending" means execution has not been finalized.
  const auditRecord: Record<string, unknown> = {
    request_id: requestId,
    actor_id: actor,
    tool_name: tool,
    decision: decision === "allow" ? "pending" : "deny",
    reason: decision === "allow" ? "Authorized; execution pending" : reason,
    execution_status: decision === "allow" ? "pending" : "not_started",
    execution_succeeded: false,
    created_at: new Date().toISOString()
  };
  const { error: auditInsertError } = await db.from("firewall_decisions").insert(auditRecord);
  if (auditInsertError) {
    return response(res, 500, { error: "Could not persist security decision; no tool was executed", decision: "deny", reason: "Audit persistence failed before execution" });
  }

  if (decision === "allow" && tool === "create_demo_note") {
    const { data, error } = await db.from("demo_actions").insert({
      actor_id: actor,
      request_id: requestId,
      action_type: "create_demo_note",
      note: (params.note as string).trim()
    }).select("id, created_at").single();
    if (error) {
      decision = "deny";
      reason = "Execution failed; no success reported";
    } else {
      actionId = data.id;
      executionResult = { id: data.id, created_at: data.created_at };
      executionSucceeded = true;
    }
  } else if (decision === "allow" && tool === "read_demo_status") {
    const { count, error } = await db.from("demo_actions").select("id", { count: "exact", head: true });
    if (error) {
      decision = "deny";
      reason = "Execution failed; no success reported";
    } else {
      executionResult = { demoActionCount: count ?? 0 };
      executionSucceeded = true;
    }
  }

  // Finalize the pre-existing audit row. A failed update is reported explicitly;
  // the row remains "pending" for operators to investigate rather than falsely
  // claiming that an action was denied or completed.
  const finalAudit = {
    decision,
    reason,
    execution_status: executionSucceeded ? "succeeded" : (decision === "allow" ? "failed" : "not_started"),
    execution_succeeded: executionSucceeded
  };
  const { error: auditUpdateError } = await db.from("firewall_decisions").update(finalAudit).eq("request_id", requestId);
  if (auditUpdateError) {
    return response(res, 500, {
      error: "Could not finalize audit record; inspect the pending request in Supabase",
      requestId,
      decision: "pending",
      reason: "Audit finalization failed; operator review required"
    });
  }
  Object.assign(auditRecord, finalAudit);

  const sheetsLogged = await mirrorToSheets(auditRecord);
  return response(res, decision === "allow" ? 200 : 403, {
    requestId,
    decision,
    reason,
    ...(actionId ? { actionId } : {}),
    ...(executionResult ? { executionResult } : {}),
    sheetsLogged
  });
}