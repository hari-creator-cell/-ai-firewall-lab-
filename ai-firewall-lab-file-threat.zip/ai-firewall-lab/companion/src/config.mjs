// Central configuration. Everything is read from environment variables.
// No secrets are hard-coded here.
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));

function int(name, dflt, env) {
  const v = Number.parseInt(env[name] ?? "", 10);
  return Number.isFinite(v) && v > 0 ? v : dflt;
}

export function loadConfig(env = process.env) {
  const host = env.COMPANION_HOST || "127.0.0.1";
  const allowedHosts = new Set(["127.0.0.1", "::1", "localhost"]);
  if (!allowedHosts.has(host) && env.COMPANION_ALLOW_NON_LOOPBACK !== "I_UNDERSTAND_THE_RISK") {
    throw new Error(
      `Refusing to bind to non-loopback host "${host}". The companion is an unauthenticated-by-network service; ` +
      `set COMPANION_ALLOW_NON_LOOPBACK=I_UNDERSTAND_THE_RISK only if you really need this.`
    );
  }
  const origins = new Set(["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:4173", "http://127.0.0.1:4173"]);
  for (const o of (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean)) origins.add(o);

  return {
    host,
    port: int("COMPANION_PORT", 8787, env),
    allowedOrigins: origins,
    // Local pairing token: generated per start unless explicitly provided.
    sessionToken: env.COMPANION_SESSION_TOKEN || randomBytes(18).toString("base64url"),
    ollamaUrl: (env.OLLAMA_URL || "http://localhost:11434").replace(/\/+$/, ""),
    model: env.OLLAMA_MODEL || "qwen3:1.7b",
    // Qwen3 is a "thinking" model. think=false asks Ollama to skip the reasoning trace.
    ollamaThink: (env.OLLAMA_THINK || "false").toLowerCase() === "true",
    ollamaNumCtx: int("OLLAMA_NUM_CTX", 8192, env),
    ollamaTimeoutMs: int("OLLAMA_TIMEOUT_MS", 120_000, env),
    ollamaStatusTimeoutMs: int("OLLAMA_STATUS_TIMEOUT_MS", 3_000, env),
    maxFileBytes: int("MAX_FILE_BYTES", 512 * 1024, env),
    maxJsonBodyBytes: int("MAX_BODY_BYTES", 1024 * 1024, env), // base64 of the file + prompt
    maxExtractedChars: int("MAX_EXTRACTED_CHARS", 12_000, env), // what can ever reach the model
    maxPromptChars: int("MAX_PROMPT_CHARS", 500, env),
    maxConcurrentInference: int("MAX_CONCURRENT_INFERENCE", 1, env),
    maxStoredRequests: int("MAX_STORED_REQUESTS", 50, env),
    requestTtlMs: int("REQUEST_TTL_MS", 15 * 60_000, env),
    // Risk score at/above which the firewall blocks. Scores are defined in scanner.mjs.
    blockThreshold: int("BLOCK_THRESHOLD", 60, env),
    reviewThreshold: int("REVIEW_THRESHOLD", 25, env),
    // "block" => REVIEW-level files are blocked (strict, default). "allow" => REVIEW files are allowed but flagged.
    reviewPolicy: (env.REVIEW_POLICY || "block").toLowerCase() === "allow" ? "allow" : "block",
    // Model tool calls are OFF by default. Even when OFF, any tool call the model emits is policy-checked and denied.
    enableModelTools: (env.ENABLE_MODEL_TOOLS || "false").toLowerCase() === "true",
    auditFile: env.AUDIT_FILE || path.resolve(here, "..", "data", "audit.jsonl"),
    // Optional: HMAC key shared with the Vercel /api/file-audit endpoint so the browser cannot forge Supabase audit rows.
    auditSyncSecret: env.AUDIT_SYNC_SECRET || "",
  };
}
