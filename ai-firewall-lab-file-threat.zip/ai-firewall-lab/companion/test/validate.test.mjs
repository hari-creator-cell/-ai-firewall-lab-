import { test } from "node:test";
import assert from "node:assert/strict";
import { validateAndExtract, decodeBase64Strict, sanitizeFilename, ValidationError } from "../src/validate.mjs";

const v = (filename, content, maxChars = 12000) => validateAndExtract({ filename, bytes: Buffer.from(content), maxChars });
const code = fn => { try { fn(); } catch (e) { return e instanceof ValidationError ? e.code : "other:" + e.message; } return null; };

test("supported plain-text types are extracted", () => {
  for (const n of ["a.txt", "a.md", "a.csv", "a.py", "A.TXT"]) assert.equal(v(n, "hello").text, "hello");
  assert.equal(v("a.json", '{"a":1}').format, "json");
});
test("unsupported types are rejected", () => {
  for (const n of ["a.exe", "a.bin", "a.docx", "a.pdf", "a.html", "noext", "a.txt.exe", ".txt"]) assert.equal(code(() => v(n, "hello")), "unsupported_type", n);
});
test("binary and disguised files are rejected", () => {
  assert.equal(code(() => v("a.txt", "%PDF-1.4 hi")), "binary_content");
  assert.equal(code(() => v("a.txt", "MZ\x90\x00")), "binary_content");
  assert.equal(code(() => v("a.txt", "abc\u0000def")), "binary_content");
  assert.equal(code(() => validateAndExtract({ filename: "a.txt", bytes: Buffer.from([0x68, 0xff, 0xfe, 0x69]), maxChars: 100 })), "malformed_text");
});
test("malformed JSON with .json extension is rejected", () => {
  assert.equal(code(() => v("a.json", "{not json")), "malformed_json");
});
test("base64 handling: oversized, malformed and empty", () => {
  assert.throws(() => decodeBase64Strict(Buffer.alloc(2000).toString("base64"), 1000), e => e.code === "file_too_large");
  assert.throws(() => decodeBase64Strict("!!!notbase64", 1000), e => e.code === "malformed_encoding");
  assert.throws(() => decodeBase64Strict("", 1000), e => e.code === "empty_file");
  assert.throws(() => decodeBase64Strict(undefined, 1000), e => e.code === "empty_file");
});
test("filenames are sanitized (path traversal, control and bidi characters)", () => {
  assert.equal(sanitizeFilename("../../etc/passwd"), "passwd");
  assert.equal(sanitizeFilename("C:\\Windows\\evil.txt"), "evil.txt");
  assert.equal(sanitizeFilename("a\u202egnp.txt"), "agnp.txt");
  assert.equal(sanitizeFilename(".."), "unnamed");
  assert.equal(sanitizeFilename(null), "unnamed");
  assert.ok(sanitizeFilename("a".repeat(500) + ".txt").length <= 120);
});
test("long text is flagged as truncated for the model (never silently)", () => {
  const r = v("a.txt", "x".repeat(500), 100);
  assert.equal(r.truncated, true);
  assert.equal(r.text.length, 500);   // scanner still sees everything
});
