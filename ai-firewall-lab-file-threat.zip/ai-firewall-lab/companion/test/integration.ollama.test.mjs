// Integration test against a REAL local Ollama. Skipped (visibly) when Ollama or the model is unavailable.
import { test } from "node:test";
import assert from "node:assert/strict";
import { loadConfig } from "../src/config.mjs";
import { getOllamaStatus } from "../src/ollama.mjs";
import { startCompanion, SAFE_DOC, INJECTION_DOC } from "./helpers.mjs";

const url = process.env.OLLAMA_URL || "http://localhost:11434";
const model = process.env.OLLAMA_MODEL || "qwen3:1.7b";
const status = await getOllamaStatus(loadConfig({ OLLAMA_URL: url, OLLAMA_MODEL: model }));
const skip = !(status.reachable && status.modelAvailable) && `SKIPPED: Ollama/model not available (${status.error})`;

test("real Ollama: allowed file reaches the model and a real response comes back", { skip, timeout: 180_000 }, async () => {
  const c = await startCompanion({ ollamaUrl: url, env: { OLLAMA_MODEL: model, OLLAMA_TIMEOUT_MS: "170000" } });
  try {
    const up = await c.upload("safe.txt", SAFE_DOC);
    assert.equal(up.json.decision, "allow");
    const run = await c.api("POST", `/v1/requests/${up.json.requestId}/run`, { prompt: "Summarize in one sentence." });
    assert.equal(run.json.state, "completed", JSON.stringify(run.json.error));
    assert.ok(run.json.response.text.length > 0);
    assert.equal(run.json.forwardedToModel, true);
    console.log("Real model replied:", run.json.response.text.slice(0, 120));
  } finally { await c.close(); }
});

test("real Ollama: injection file is blocked and never forwarded", { skip, timeout: 30_000 }, async () => {
  const c = await startCompanion({ ollamaUrl: url, env: { OLLAMA_MODEL: model } });
  try {
    const up = await c.upload("inj.txt", INJECTION_DOC);
    assert.equal(up.json.decision, "block");
    assert.equal(up.json.forwardedToModel, false);
  } finally { await c.close(); }
});
