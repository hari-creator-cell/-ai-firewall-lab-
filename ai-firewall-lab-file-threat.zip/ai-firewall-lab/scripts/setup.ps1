# One-time setup for Windows (PowerShell). Run from the project root:  powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

Write-Host "== AI Firewall Lab: setup ==" -ForegroundColor Cyan

# 1. Node.js
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) { Write-Host "Node.js not found. Install Node 20+ LTS from https://nodejs.org and re-run." -ForegroundColor Red; exit 1 }
$ver = (node -v).TrimStart("v").Split(".")[0]
if ([int]$ver -lt 20) { Write-Host "Node $ver is too old. Install Node 20+." -ForegroundColor Red; exit 1 }
Write-Host "Node $(node -v) OK"

# 2. Companion env file (no secrets are generated or stored here)
if (-not (Test-Path "companion\.env")) { Copy-Item "companion\.env.example" "companion\.env"; Write-Host "Created companion\.env" } else { Write-Host "companion\.env already exists (kept)" }

# 3. Frontend dependencies (the companion itself has ZERO npm dependencies)
if (-not (Test-Path ".env.local")) { Copy-Item ".env.example" ".env.local"; Write-Host "Created .env.local -> fill in your Supabase values" -ForegroundColor Yellow }
npm install

# 4. Ollama + model check (does NOT download anything)
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) { Write-Host "ollama command not found on PATH (the app may still be running; the companion checks the HTTP API)." -ForegroundColor Yellow }
else {
  $list = (& ollama list) -join "`n"
  if ($list -match "qwen3:1.7b") { Write-Host "Model qwen3:1.7b is already installed." -ForegroundColor Green }
  else { Write-Host "Model qwen3:1.7b not listed. Run:  ollama pull qwen3:1.7b" -ForegroundColor Yellow }
}

# 5. Run the automated tests (real-Ollama tests are skipped automatically if Ollama is not running)
npm --prefix companion test
Write-Host "Setup finished. Next: scripts\run.ps1" -ForegroundColor Green
