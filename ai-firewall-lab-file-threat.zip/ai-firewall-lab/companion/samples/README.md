# Synthetic demo files (harmless)

| File | Scenario | Expected firewall result |
|---|---|---|
| `scenario-a-safe.txt` | A – safe document | ALLOWED, content sent to Qwen |
| `scenario-b-injection.txt` | B – prompt injection | BLOCKED, never sent to Qwen |
| `scenario-c-unsupported.bin` | C – unsupported type | Rejected at validation |

`scenario-c-disguised-binary.txt.b64` is base64 of a tiny text blob that starts with a PDF magic number
(`%PDF`). Decode it to `scenario-c-disguised-binary.txt` (PowerShell: `[IO.File]::WriteAllBytes("scenario-c-disguised-binary.txt",[Convert]::FromBase64String((Get-Content scenario-c-disguised-binary.txt.b64 -Raw)))`)
to demonstrate that renamed files are caught by content checks. None of these files is malware.
