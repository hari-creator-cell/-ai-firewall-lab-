// Local audit trail (append-only JSON Lines) + HMAC signing for optional Supabase sync.
// Records never contain document text, prompts, or model output.
import { appendFile, mkdir, readFile } from "node:fs/promises";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import path from "node:path";

export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonicalJson(value[k])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
export function signRecord(record, secret) {
  return createHmac("sha256", secret).update(canonicalJson(record)).digest("hex");
}
export function verifySignature(record, signature, secret) {
  const a = Buffer.from(signRecord(record, secret), "hex");
  let b; try { b = Buffer.from(String(signature), "hex"); } catch { return false; }
  return a.length === b.length && timingSafeEqual(a, b);
}
export const sha12 = s => createHash("sha256").update(String(s)).digest("hex").slice(0, 12);

export function createAuditLog(file) {
  return {
    file,
    /** Returns { ok, error? }. Callers must NOT claim a record was saved unless ok === true. */
    async write(record) {
      try {
        await mkdir(path.dirname(file), { recursive: true });
        await appendFile(file, JSON.stringify(record) + "\n", { encoding: "utf8", mode: 0o600 });
        return { ok: true };
      } catch (err) {
        return { ok: false, error: String(err && err.code || err && err.message || err) };
      }
    },
    async recent(limit = 25) {
      try {
        const text = await readFile(file, "utf8");
        return text.split("\n").filter(Boolean).slice(-limit).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      } catch { return []; }
    },
  };
}

/** Build the privacy-preserving audit record from a request record. */
export function buildAuditRecord(r, stage, cfg, sessionId) {
  return {
    request_id: r.id,
    stage,                                   // "decided" | "final"
    actor: `local-session:${sessionId}`,
    file_id: `${sha12(r.file?.filename ?? "")}${r.file?.extension ?? ""}`,   // hash, not the filename
    file_size: r.file?.sizeBytes ?? null,
    detected_format: r.file?.format ?? null,
    scan_status: r.scan ? r.scan.status : "not_run",
    risk_score: r.scan?.riskScore ?? null,
    detection_categories: r.scan?.categories ?? [],
    decision: r.decision,
    reason_code: r.reasonCode,
    ollama_invoked: r.ollamaInvoked,
    model: cfg.model,
    final_status: r.state,
    tool_calls: r.toolCalls.map(t => ({ name: String(t.name).slice(0, 40), allowed: t.allowed, executed: t.executed })),
    created_at: r.createdAt,
    recorded_at: new Date().toISOString(),
  };
}
