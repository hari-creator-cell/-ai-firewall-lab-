// Receives a companion-signed audit record and stores it in Supabase.
// Trust model: (1) the Supabase access token proves WHO is syncing, (2) the HMAC proves the record
// was produced by a companion that holds AUDIT_SYNC_SECRET, so the browser cannot forge decisions.
// The service-role key stays on Vercel; it never goes to the laptop or the browser.
import { createClient } from "@supabase/supabase-js";
import { createHmac, timingSafeEqual } from "node:crypto";

type VercelRequest = { method?: string; headers: Record<string, string | string[] | undefined>; body: unknown };
type VercelResponse = { setHeader(name: string, value: string): void; status(code: number): VercelResponse; json(body: unknown): unknown };

function canonicalJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const o = value as Record<string, unknown>;
    return `{${Object.keys(o).sort().map(k => `${JSON.stringify(k)}:${canonicalJson(o[k])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function validSignature(record: unknown, signature: unknown, secret: string): boolean {
  if (typeof signature !== "string" || !/^[0-9a-f]{64}$/.test(signature)) return false;
  const expected = createHmac("sha256", secret).update(canonicalJson(record)).digest();
  return timingSafeEqual(expected, Buffer.from(signature, "hex"));
}

const str = (v: unknown, max: number) => (typeof v === "string" && v.length <= max ? v : null);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY, secret = process.env.AUDIT_SYNC_SECRET;
  if (!url || !key) return res.status(500).json({ error: "Server is missing Supabase configuration" });
  if (!secret) return res.status(501).json({ error: "AUDIT_SYNC_SECRET is not configured on the server" });

  const raw = req.headers.authorization;
  const authorization = Array.isArray(raw) ? raw[0] : raw;
  if (typeof authorization !== "string" || !authorization.startsWith("Bearer ")) return res.status(401).json({ error: "Missing bearer token" });
  const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: authData, error: authError } = await db.auth.getUser(authorization.slice(7));
  if (authError || !authData.user) return res.status(401).json({ error: "Invalid or expired session" });

  if (JSON.stringify(req.body ?? {}).length > 8000) return res.status(413).json({ error: "Request too large" });
  const body = req.body as { record?: Record<string, unknown>; signature?: unknown };
  if (!body || typeof body.record !== "object" || body.record === null) return res.status(400).json({ error: "Expected { record, signature }" });
  if (!validSignature(body.record, body.signature, secret)) return res.status(403).json({ error: "Invalid audit signature" });

  const r = body.record;
  const requestId = str(r.request_id, 40);
  if (!requestId || !/^[0-9a-f-]{36}$/.test(requestId) || (r.stage !== "final")) return res.status(400).json({ error: "Malformed audit record" });
  const row = {
    request_id: requestId,
    actor_id: authData.user.id,                       // from the verified token, never from the record
    local_actor: str(r.actor, 80),
    file_id: str(r.file_id, 40),
    file_size: typeof r.file_size === "number" ? r.file_size : null,
    detected_format: str(r.detected_format, 20),
    scan_status: str(r.scan_status, 20),
    risk_score: typeof r.risk_score === "number" ? Math.round(r.risk_score) : null,
    detection_categories: Array.isArray(r.detection_categories) ? r.detection_categories.filter((c): c is string => typeof c === "string").slice(0, 12).map(c => c.slice(0, 80)) : [],
    decision: r.decision === "allow" ? "allow" : "block",
    reason_code: str(r.reason_code, 60),
    ollama_invoked: r.ollama_invoked === true,
    model: str(r.model, 60),
    final_status: str(r.final_status, 20),
    tool_calls: Array.isArray(r.tool_calls) ? r.tool_calls.slice(0, 5) : [],
    created_at: str(r.created_at, 40),
  };
  const { error } = await db.from("file_scan_audit").insert(row);
  if (error) {
    if (error.code === "23505") return res.status(200).json({ saved: true, duplicate: true });
    return res.status(500).json({ error: "Could not store audit record" });
  }
  return res.status(200).json({ saved: true });
}
