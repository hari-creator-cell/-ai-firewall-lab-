# AI Firewall Lab — working MVP scaffold

This project is a small real backend prototype:
- React + Vite frontend
- Supabase Auth for user sessions
- Vercel serverless API as the policy enforcement point
- Supabase Postgres for policies, real demo actions, and authoritative audit records
- Google Sheets as a secondary audit mirror

It is intentionally limited to two safe demo tools: `create_demo_note` and `read_demo_status`. `delete_all_data`, unknown tools, invalid inputs, and unconfigured policies are denied. It does not execute arbitrary shell commands, browse arbitrary URLs, send email, or access arbitrary Drive files.

## NEW: File Threat Detection (local Ollama + Qwen3 firewall)

A local companion service now scans uploaded text files for prompt injection **before** they reach Qwen3 1.7B (Ollama), blocks unsafe files server-side, and records an audit trail. Existing tool-gateway features, Supabase auth and tables are unchanged. See [`docs/FILE_THREAT_DETECTION.md`](docs/FILE_THREAT_DETECTION.md) for setup (`scripts\setup.ps1`, `scripts\run.ps1`), the demo script, tests and limitations.

## 1. Create Supabase project

1. Create a project at https://supabase.com.
2. Open **SQL Editor** and run all of `supabase/schema.sql`.
3. In **Authentication → Providers**, enable Email.
4. For a hackathon, decide whether to require email confirmation. If confirmation is enabled, users must confirm before signing in.
5. In Project Settings / API, copy the project URL, publishable/anon key, and service-role/secret key. Never put the service-role key in frontend variables.

## 2. Configure locally

Install Node.js 20 or later. Unzip the project and run:

```bash
npm install
cp .env.example .env.local
```

Fill in:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`

The first two are browser-visible. The last two are server-side values; the service role must never have a `VITE_` prefix.

Run locally:

```bash
npm run dev
```

Vite does not automatically run Vercel API functions locally. To test `/api/firewall` locally, use the Vercel CLI (`vercel dev`) after installing/logging into Vercel and linking the project, or deploy a preview first.

## 3. Deploy to Vercel

1. Push the project to a private or public Git repository.
2. Import that repository into https://vercel.com.
3. Add the environment variables from `.env.example` in Vercel Project Settings → Environment Variables.
4. Deploy.
5. Test account creation/sign-in and submit each tool action. The allowed demo note should create a row in `demo_actions`; destructive/unknown tools should be denied and logged in `firewall_decisions`.

## 4. Optional Google Sheets mirror

1. Create a Google Spreadsheet for the audit mirror.
2. Open **Extensions → Apps Script** and paste `google-apps-script/Code.gs`.
3. In Apps Script **Project Settings → Script Properties**, add `WEBHOOK_SECRET` with a long random value.
4. Deploy as a Web App and copy the `/exec` URL.
5. Set `SHEETS_WEBHOOK_URL` and `SHEETS_WEBHOOK_SECRET` in Vercel environment variables. `SHEETS_WEBHOOK_SECRET` must exactly match the Apps Script Script Property.
6. Redeploy Vercel so the new environment variables are applied.

Supabase is authoritative. A Sheets logging failure is reported as `sheetsLogged: false`; the decision remains in Supabase. Never rely on Sheets to authorize a request.

## 5. Important prototype security notes

- The Vercel API verifies the Supabase access token using `auth.getUser()`.
- Policy evaluation and execution happen server-side.
- The service-role key is used only by the Vercel API.
- The API has a server-side allowlist and hard-deny list; database policy cannot enable arbitrary tools.
- An audit intent is inserted before any allowed tool executes; the record is then finalized with the execution outcome. If the initial audit insert fails, execution is not started. If finalization fails, the record remains pending and the API reports the request ID for operator review.
- The Sheets webhook uses a shared secret and formula-injection protection.
- This scaffold is not a production-certified security product. It does not yet implement human approval workflows, rate limiting, abuse monitoring, tamper-evident audit chaining, or arbitrary third-party tool adapters. The pending audit state reduces ambiguity around execution failures but does not make the action and audit update a single atomic transaction; use a database RPC transaction before treating this as production-ready. Do not add risky real tools without a separate security review.

## 6. Basic acceptance tests

1. Sign in and submit `create_demo_note` with a short note: expect `allow`, then verify a row in `demo_actions` and `firewall_decisions`.
2. Submit `delete_all_data`: expect `deny`, with no destructive execution.
3. Submit `unknown_tool`: expect default-deny.
4. Submit a note longer than 200 characters using the API directly: expect validation denial.
5. Temporarily change the Sheets URL to an invalid URL: action decision should still be recorded in Supabase, and the response should show `sheetsLogged: false`.
6. Try direct browser inserts into `demo_actions` or `firewall_decisions`: they should be blocked by grants/RLS.

Before presenting, run the tests and inspect Supabase rows. Do not describe untested behavior as verified.


## Audit consistency improvement in this revision

The gateway now inserts a `pending` audit record before executing an allowed tool. If the insert fails, the tool is not executed. After execution, the gateway updates the same record with the final decision and `execution_status`. If finalization fails, the API returns a `requestId` and leaves a pending row for investigation. This is safer than executing first and only then attempting to create the audit row, but a production-grade version should move the demo action and audit finalization into one PostgreSQL transaction/RPC.

If you already ran an older schema, run the updated `supabase/schema.sql` in the Supabase SQL Editor to apply the migration-safe constraint and column changes. Back up existing data before applying schema changes to a project with important data.
