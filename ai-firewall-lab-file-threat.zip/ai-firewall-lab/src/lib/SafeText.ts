// Renders untrusted text (filenames, document excerpts, model output) strictly as TEXT NODES.
// React escapes text children, and this component never injects raw HTML.
import { createElement } from "react";

/** Remove control/bidi characters and cap the length. Used for anything derived from untrusted files. */
export function cleanUntrusted(value: unknown, max = 400): string {
  const s = typeof value === "string" ? value : String(value ?? "");
  const cleaned = s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "");
  return cleaned.length > max ? cleaned.slice(0, max - 1) + "…" : cleaned;
}

export function SafeText(props: { text: unknown; max?: number; className?: string; as?: "span" | "code" | "pre" | "p" }) {
  return createElement(props.as ?? "span", { className: props.className }, cleanUntrusted(props.text, props.max ?? 400));
}
