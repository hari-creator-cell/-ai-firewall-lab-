// Minimal Ollama client using the documented REST API:
//   GET  /api/tags  -> { models: [ { name, model, size, ... } ] }
//   POST /api/chat  -> { model, created_at, message: { role, content, thinking?, tool_calls? }, done, done_reason, ... }  (stream:false)
// The response shape is validated defensively; anything unexpected becomes an OllamaError (fail closed).

export class OllamaError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

function withTimeout(ms, outer) {
  const signals = [AbortSignal.timeout(ms)];
  if (outer) signals.push(outer);
  return AbortSignal.any(signals);
}

function normalizeModelName(n) { return String(n).includes(":") ? String(n) : `${n}:latest`; }

export async function getOllamaStatus(cfg, fetchImpl = fetch) {
  const base = { reachable: false, modelAvailable: false, model: cfg.model, installedModels: [], error: null, checkedAt: new Date().toISOString() };
  try {
    const res = await fetchImpl(`${cfg.ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(cfg.ollamaStatusTimeoutMs) });
    if (!res.ok) return { ...base, error: `Ollama returned HTTP ${res.status} for /api/tags` };
    const data = await res.json();
    if (!data || !Array.isArray(data.models)) return { ...base, reachable: true, error: "Unexpected /api/tags response shape" };
    const names = data.models.map(m => (m && (m.name || m.model))).filter(n => typeof n === "string");
    const want = normalizeModelName(cfg.model);
    return { ...base, reachable: true, installedModels: names.slice(0, 20), modelAvailable: names.some(n => normalizeModelName(n) === want),
      error: names.some(n => normalizeModelName(n) === want) ? null : `Model "${cfg.model}" is not installed in Ollama (run: ollama pull ${cfg.model}).` };
  } catch (err) {
    const timedOut = err && (err.name === "TimeoutError" || err.name === "AbortError");
    return { ...base, error: timedOut ? "Timed out connecting to Ollama" : `Cannot connect to Ollama at ${cfg.ollamaUrl} (is it running?)` };
  }
}

const MAX_RESPONSE_CHARS = 8000;

export function stripThinking(s) {
  return s.replace(/<think>[\s\S]*?<\/think>/gi, "").replace(/^[\s\S]*?<\/think>/i, "").trim();
}

/**
 * One non-streaming chat call. `system` and `user` are built by the caller; this function
 * never decides whether a request is allowed (that already happened in the firewall).
 */
export async function ollamaChat(cfg, { system, user, tools, signal }, fetchImpl = fetch) {
  const body = {
    model: cfg.model, stream: false, think: cfg.ollamaThink,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
    options: { temperature: 0.2, num_ctx: cfg.ollamaNumCtx },
  };
  if (tools && tools.length) body.tools = tools;
  let res;
  try {
    res = await fetchImpl(`${cfg.ollamaUrl}/api/chat`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      signal: withTimeout(cfg.ollamaTimeoutMs, signal),
    });
  } catch (err) {
    if (signal?.aborted) throw new OllamaError("aborted", "Request cancelled.");
    if (err && err.name === "TimeoutError") throw new OllamaError("timeout", `Ollama did not respond within ${cfg.ollamaTimeoutMs / 1000}s.`);
    if (err && err.name === "AbortError") throw new OllamaError("aborted", "Request aborted.");
    throw new OllamaError("unreachable", `Cannot connect to Ollama at ${cfg.ollamaUrl}.`);
  }
  if (!res.ok) {
    let detail = "";
    try { detail = String((await res.json())?.error || "").slice(0, 200); } catch { /* ignore */ }
    if (res.status === 404) throw new OllamaError("model_missing", detail || `Model "${cfg.model}" not found.`);
    throw new OllamaError("http_error", `Ollama returned HTTP ${res.status}${detail ? `: ${detail}` : ""}`);
  }
  let data;
  try { data = await res.json(); } catch { throw new OllamaError("bad_response", "Ollama returned invalid JSON."); }
  const msg = data && data.message;
  if (!msg || typeof msg !== "object" || typeof msg.content !== "string") {
    throw new OllamaError("bad_response", "Ollama response is missing message.content.");
  }
  const toolCalls = Array.isArray(msg.tool_calls)
    ? msg.tool_calls.map(tc => ({ name: String(tc?.function?.name ?? ""), arguments: tc?.function?.arguments ?? {} })).slice(0, 5) : [];
  let content = stripThinking(msg.content);
  const truncated = content.length > MAX_RESPONSE_CHARS;
  if (truncated) content = content.slice(0, MAX_RESPONSE_CHARS);
  return {
    content, truncated, toolCalls, model: typeof data.model === "string" ? data.model : cfg.model,
    done: data.done === true, doneReason: typeof data.done_reason === "string" ? data.done_reason : null,
    totalDurationMs: typeof data.total_duration === "number" ? Math.round(data.total_duration / 1e6) : null,
    evalCount: typeof data.eval_count === "number" ? data.eval_count : null,
  };
}
