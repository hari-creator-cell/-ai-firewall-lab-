// UI escaping test: untrusted text must render as text nodes, never as markup.
import { test } from "node:test";
import assert from "node:assert/strict";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { SafeText, cleanUntrusted } from "../src/lib/SafeText.ts";

const payloads = ['<img src=x onerror=alert(1)>', '<script>alert("x")</script>', '"><svg onload=alert(1)>', "javascript:alert(1)"];

test("untrusted content (filename, excerpts, model output) is HTML-escaped by the UI component", () => {
  for (const p of payloads) {
    for (const as of ["span", "code", "pre", "p"]) {
      const html = renderToStaticMarkup(createElement(SafeText, { text: p, as }));
      assert.ok(!/<(img|script|svg)/i.test(html), `markup leaked: ${html}`);
      assert.ok(html.includes("&lt;") || !p.includes("<"), html);
    }
  }
});

test("control and bidi characters are removed and length is capped", () => {
  assert.equal(cleanUntrusted("a\u202eb\u0007c"), "abc");
  assert.ok(cleanUntrusted("x".repeat(5000), 100).length <= 100);
  const html = renderToStaticMarkup(createElement(SafeText, { text: "x".repeat(5000), max: 50 }));
  assert.ok(html.length < 200);
});

test("UI source never uses dangerouslySetInnerHTML or innerHTML", async () => {
  const { readFile } = await import("node:fs/promises");
  for (const f of ["../src/FileThreatDetection.tsx", "../src/lib/SafeText.ts", "../src/lib/companion.ts"]) {
    const src = await readFile(new URL(f, import.meta.url), "utf8");
    assert.ok(!/dangerouslySetInnerHTML|\.innerHTML\s*=/.test(src), f);
  }
});
