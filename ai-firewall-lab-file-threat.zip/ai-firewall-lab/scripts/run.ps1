# Starts the local companion (loopback only) and, optionally, the web UI. Run from anywhere:
#   powershell -ExecutionPolicy Bypass -File scripts\run.ps1            # companion + Vite dev server
#   powershell -ExecutionPolicy Bypass -File scripts\run.ps1 -NoUi      # companion only (use the Vercel site)
param([switch]$NoUi)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

# Is Ollama answering? (Informational; the companion also reports this in the UI.)
try { $t = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -TimeoutSec 3; Write-Host "Ollama is running ($($t.models.Count) model(s) installed)." -ForegroundColor Green }
catch { Write-Host "WARNING: Ollama is not reachable on http://localhost:11434. Start it first (open the Ollama app or run: ollama serve)." -ForegroundColor Yellow }

if (-not $NoUi) {
  Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$root'; npm run dev"
  Write-Host "Web UI starting in a new window: http://localhost:5173" -ForegroundColor Cyan
}
Write-Host "Starting companion. Copy the PAIRING TOKEN below into the File Threat Detection panel." -ForegroundColor Cyan
node companion\src\server.mjs
