-- AI Firewall Lab MVP schema.
-- Run in Supabase SQL Editor. Do not expose service_role credentials to the browser.

create extension if not exists pgcrypto;

create table if not exists public.tool_policies (
  tool_name text primary key,
  enabled boolean not null default false,
  requires_approval boolean not null default true,
  allowed_params text[] not null default '{}',
  description text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists public.demo_actions (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references auth.users(id) on delete cascade,
  request_id uuid not null unique,
  action_type text not null check (action_type in ('create_demo_note')),
  note text not null check (char_length(note) between 1 and 200),
  created_at timestamptz not null default now()
);

create table if not exists public.firewall_decisions (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique,
  actor_id uuid not null references auth.users(id) on delete cascade,
  tool_name text not null,
  decision text not null check (decision in ('allow', 'deny', 'pending')),
  reason text not null,
  execution_status text not null default 'not_started' check (execution_status in ('not_started', 'pending', 'succeeded', 'failed')),
  execution_succeeded boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.tool_policies enable row level security;
alter table public.demo_actions enable row level security;
-- Upgrade existing MVP tables safely when re-running this schema.
alter table public.firewall_decisions drop constraint if exists firewall_decisions_decision_check;
alter table public.firewall_decisions add constraint firewall_decisions_decision_check check (decision in ('allow', 'deny', 'pending'));
alter table public.firewall_decisions add column if not exists execution_status text not null default 'not_started';
alter table public.firewall_decisions drop constraint if exists firewall_decisions_execution_status_check;
alter table public.firewall_decisions add constraint firewall_decisions_execution_status_check check (execution_status in ('not_started', 'pending', 'succeeded', 'failed'));

alter table public.firewall_decisions enable row level security;

-- No direct browser reads/writes for policy or audit tables. Server uses service-role key.
revoke all on public.tool_policies from anon, authenticated;
revoke all on public.demo_actions from anon, authenticated;
revoke all on public.firewall_decisions from anon, authenticated;

-- Users can read only their own demo actions; they cannot create or alter them directly.
grant select on public.demo_actions to authenticated;
create policy "users can read own demo actions"
on public.demo_actions for select to authenticated
using ((select auth.uid()) = actor_id);

-- Users can read their own decisions. Writes are server-only.
grant select on public.firewall_decisions to authenticated;
create policy "users can read own firewall decisions"
on public.firewall_decisions for select to authenticated
using ((select auth.uid()) = actor_id);

-- Seed conservative policies. The server also has a hardcoded tool allowlist and hard-deny list.
insert into public.tool_policies (tool_name, enabled, requires_approval, allowed_params, description)
values
  ('create_demo_note', true, false, array['note'], 'Creates a note in the dedicated demo_actions table'),
  ('read_demo_status', true, false, array[]::text[], 'Returns a count of demo actions'),
  ('delete_all_data', false, true, array[]::text[], 'Hard-denied destructive action')
on conflict (tool_name) do update set
  enabled = excluded.enabled,
  requires_approval = excluded.requires_approval,
  allowed_params = excluded.allowed_params,
  description = excluded.description,
  updated_at = now();

-- Optional index for recent audit queries.
create index if not exists firewall_decisions_created_at_idx on public.firewall_decisions (created_at desc);
create index if not exists demo_actions_actor_created_at_idx on public.demo_actions (actor_id, created_at desc);